
@SuppressWarnings("serial")
public class negativeInputException extends RuntimeException{
	negativeInputException(String msg) {
		super(msg);
	}
}
