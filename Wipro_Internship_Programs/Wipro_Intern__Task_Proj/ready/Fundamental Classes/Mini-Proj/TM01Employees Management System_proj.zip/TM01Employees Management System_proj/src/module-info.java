module EMS {
	/**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 * In this project i had created three classes, one of them to provides
	 * implementation guidance which to the tester class 
	 * Entry package class is there to store the entities of the variables and values
	 * and final tester class to test the project is qualify the requirements or n
	 * ot.
	 */
}