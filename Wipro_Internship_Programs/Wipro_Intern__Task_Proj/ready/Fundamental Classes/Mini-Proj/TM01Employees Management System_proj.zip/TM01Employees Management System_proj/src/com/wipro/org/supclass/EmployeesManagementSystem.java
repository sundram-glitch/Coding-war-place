package com.wipro.org.supclass;
import com.wipro.org.entry.EmployeesTable;
/**
 * @author Sundram Dubey_21868788
 * superset id : 763985
 */
public interface EmployeesManagementSystem {
EmployeesTable checkEmpid(EmployeesTable[] empArr, int id);
}
