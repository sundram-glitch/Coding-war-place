package com.wipro.org;
import java.util.Scanner;
public class Problem03 {
	/**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
   public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int input1 = sc.nextInt();
	int input2 = sc.nextInt();
	System.out.println("The sum of 10 and 20 is "+(input1+input2));
   }
}
