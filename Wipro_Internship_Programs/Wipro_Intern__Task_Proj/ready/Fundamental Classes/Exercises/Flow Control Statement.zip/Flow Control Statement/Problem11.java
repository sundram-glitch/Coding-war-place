package com.wipro.org;
public class Problem11 {
	/**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
   public static void main(String[] args) {
	 for (int i = 23; i <57; i++) 
     if(i%2==0) System.out.println(i); 
   }
}
