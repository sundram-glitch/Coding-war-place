package com.wipro.org.CourtryExceptionHandler;
public class Student {
   String studentName, country;

public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}  
}
