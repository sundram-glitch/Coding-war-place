package com.wipro.org.customexception;
public class Student {
	/**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
    public Student(String name, int math, int science, int english) {
 	 this.name = name;
 	 this.math = math;
 	 this.science = science;
 	 this.english = english;
    }
	String name;
    int math, science, english;
}
