package com.wipro.org.packages;
import test.Foundation1;
public class testFoundation {
  public static void main(String[] args) {
	  Foundation1 obj = new Foundation1();
	  System.out.println(obj.var4);
	  // System.out.println(obj.var3);
	  //System.out.println(obj.var2);
	  //System.out.println(obj.var1);
  }
}
