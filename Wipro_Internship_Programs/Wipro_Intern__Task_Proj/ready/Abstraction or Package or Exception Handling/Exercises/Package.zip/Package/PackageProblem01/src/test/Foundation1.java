package test;
//Problem 1:
public class Foundation1 {
	/**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
  private int val1;
  int var2;
  protected int var3;
  public int var4;
}
