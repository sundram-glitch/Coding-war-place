package com.wipro.automobile.ship;

public class Ship {

}
