package com.wipro.org.problem2;

public class Compartment {
	/**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
  int height, weidth, breath;
}
