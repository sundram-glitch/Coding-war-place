package com.wipro.org.abscls;

public class Luggage extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return this.toString();
	}

}
