package com.wipro.org.abscls;
public abstract class Compartment {
  public abstract String notice();
}

