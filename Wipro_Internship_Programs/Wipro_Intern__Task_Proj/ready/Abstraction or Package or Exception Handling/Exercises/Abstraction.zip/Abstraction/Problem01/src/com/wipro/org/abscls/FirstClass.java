package com.wipro.org.abscls;

public class FirstClass extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return this.toString();
	}

}
