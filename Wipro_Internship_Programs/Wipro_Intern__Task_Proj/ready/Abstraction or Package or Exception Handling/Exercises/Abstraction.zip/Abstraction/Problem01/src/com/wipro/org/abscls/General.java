package com.wipro.org.abscls;

public class General extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return this.toString();
	}

}
