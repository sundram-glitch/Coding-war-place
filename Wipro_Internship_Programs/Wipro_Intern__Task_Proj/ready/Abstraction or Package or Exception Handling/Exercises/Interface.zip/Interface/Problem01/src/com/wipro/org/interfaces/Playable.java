package com.wipro.org.interfaces;

public interface Playable {
   void play();
}
