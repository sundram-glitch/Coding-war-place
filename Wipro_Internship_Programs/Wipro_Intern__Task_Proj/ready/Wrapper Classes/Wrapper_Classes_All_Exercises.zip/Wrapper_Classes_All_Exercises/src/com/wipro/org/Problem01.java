package com.wipro.org;
public class Problem01 {
	 /**
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
	public static void main(String[] args) {
    System.out.println("Integer range:\nmin :"+(Integer.MIN_VALUE)+"\nmax:"+(Integer.MAX_VALUE));
    System.out.println("Double range:\nmin :"+(Double.MIN_VALUE)+"\nmax:"+(Double.MAX_VALUE));
    System.out.println("Long range:\nmin :"+(Long.MIN_VALUE)+"\nmax:"+(Long.MAX_VALUE));
    System.out.println("Short range:\nmin :"+(Short.MIN_VALUE)+"\nmax:"+(Short.MAX_VALUE));
    System.out.println("Byte range:\nmin :"+(Byte.MIN_VALUE)+"\nmax:"+(Byte.MAX_VALUE));
    System.out.println("Float range:\nmin :"+(Float.MIN_VALUE)+"\nmax:"+(Float.MAX_VALUE));    
	}
}
