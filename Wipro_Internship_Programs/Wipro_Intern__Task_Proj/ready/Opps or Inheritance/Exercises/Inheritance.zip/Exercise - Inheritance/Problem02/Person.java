package com.wipro.org.interitenceInPerson;

public class Person {
  String name;
public Person(String name) {
  this.name = name;
}
}
