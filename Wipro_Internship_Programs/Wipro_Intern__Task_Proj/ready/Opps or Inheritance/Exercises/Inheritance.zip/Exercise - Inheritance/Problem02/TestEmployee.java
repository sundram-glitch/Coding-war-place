package com.wipro.org.interitenceInPerson;

public class TestEmployee {
	     /**4/2/2022
	 * @author Sundram Dubey_21868788
	 * superset id : 763985
	 **/
  public static void main(String[] args) {
	  Person  person1 = new Person("Sundram");
	  Employee emp1 = new Employee(person1,2234.2, 2022, "213421341" );
  } 
}
