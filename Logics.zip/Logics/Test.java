class Test {
	public static void main(String[] args){
		java.util.Scanner scn = new java.util.Scanner(System.in);
		int n = scn.nextInt();
		int arr[] = new int [n];
		int sum=0;
		for (int i=0;i<n ;i++)	arr[i]=scn.nextInt();
		for (int i=1;i<n ;i++ ) sum +=arr[i];
		if(sum==0)System.out.println(1);
		else System.out.println(0);
	}
}
