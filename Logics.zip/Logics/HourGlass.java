import java.io.*;
import java.math.*;
import java.util.*;

class Result {
    public static int hourglassSum(int[][] array) {
   
    int MaxSum = Integer.MIN_VALUE,sum=Integer.MIN_VALUE;
    for(int row=0;row<4;row++)
     for(int col=0; col<4;col++){
       sum =array[row][col]+array[row][col+1]+array[row][col+2]
                           +array[row+1][col+1]
            +array[row+2][col]+array[row+2][col+1]+array[row+2][col+2];
       MaxSum=Math.max(MaxSum,sum);
    }
    return MaxSum;
    }

}

public class Solution {
    public static void main(String[] args) throws IOException {
       
        int arr[][]=new int[6][6];
        Scanner scanf=new Scanner(System.in);
        for(int i=0; i<6;i++)
            for(int j=0;j<6;j++){
            arr[i][j]=scanf.nextInt(); 
            }
        System.out.print(Result.hourglassSum(arr));
    }
}
