class Test01
{
	public static void main(String[] args) 
	{
	/*int x=0;
	if(x>4) System.out.println("Brinda");
	else if(x>10) System.out.println("karthik");
	if(x>21) System.out.println("Pradeep");
	else  System.out.println("Sandeep");
	*/
	/*char ch ='A';
System.out.printf("%d\n",(int)ch);*/
/*int x =4, y=5;
Func(x,y);
	}*/
	int num = 8;
System.out.printf("%d %d", num<< 1,num >>1);
	}

	static void Func(int x,int y){
    if(x>1) Func(x-1,y+2);
System.out.print(y);
	}
}
