package controlflow.statement.loops;

import java.util.Arrays;
import java.util.Scanner;

public class StringArr {
 public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	 String [] strArr = new String[7];
	 //System.out.println(strArr.length);
	 for (int i = 0; i < strArr.length; i++) 
		 strArr[i] = sc.nextLine();
	 System.out.println(Arrays.toString(strArr));
  }
}
