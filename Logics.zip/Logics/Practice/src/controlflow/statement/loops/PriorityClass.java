package controlflow.statement.loops;

import java.util.*;

public class PriorityClass {
  public static void main(String[] args) {
	PriorityQueue<Integer> pq = new  PriorityQueue<Integer>();
	Scanner sc = new Scanner(System.in);  
	ArrayList<Integer>	al = new ArrayList<Integer>();
	int N = sc.nextInt();
	int K = sc.nextInt();
	for (int i = 0; i < N; i++)
	  al.add(sc.nextInt());
	System.out.println(al);
    for (int i = 0; i < al.size(); i++) {
		if(i<K) pq.add(al.get(i));
		else if(pq.peek()<al.get(i)) {
			pq.poll();
			pq.add(al.get(i));
		}
    }
    System.out.println(pq);
    ArrayList<Integer> ans = new ArrayList<Integer>(pq);
    Collections.sort(ans, Collections.reverseOrder());
  System.out.println(ans);
  }
}