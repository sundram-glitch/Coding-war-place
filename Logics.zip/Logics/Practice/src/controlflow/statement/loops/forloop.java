package controlflow.statement.loops;

import java.util.*;

public class forloop {
  public static void main(String[] args) {
	int arr[] = {1,2,3,4};
	int y = 3;
  check(arr, 3);
  }

  static int check(int[] arr, int i) {
	  for (int j = 0; j < arr.length-1; j++) {
		arr[j] = arr[j]+arr[j+1];
		
	}
	arr[0] = arr[0]+arr[1];
	arr[1] = arr[0]+arr[2];
	  return 0; 
  }
}
