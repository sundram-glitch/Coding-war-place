package controlflow.statement.loops;

import java.util.ArrayList;
import java.util.Scanner;

public class CollectionMethods {
  public static void main(String[] args) {
	 ArrayList<Integer> al  = new ArrayList<Integer>();
	 Scanner sc = new Scanner(System.in);
	 for (int i = 0; i < 5; i++)
		 al.add(sc.nextInt());
	 System.out.println(al);
	 int temp = al.get(0), i = 0; 
	 for (i = 0; i < al.size()-1; i++) { 
		 al.add(i,al.get(i+1));
         al.remove(i+1);
	 }
	 al.add(3,10);
	 al.add(i,temp);
	 al.remove(i+1);
	 System.out.println(al);
	 }
}
