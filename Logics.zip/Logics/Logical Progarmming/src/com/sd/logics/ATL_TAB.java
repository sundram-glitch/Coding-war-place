package com.sd.logics;

import java.util.LinkedHashSet;
import java.util.Scanner;

public class ATL_TAB {
 public static void main(String[] args) {
	 Scanner scan = new Scanner(System.in);
	 int tc = scan.nextInt();
	 while(tc !=0) {
	 int arrsize = scan.nextInt();
	 int alt_tab = scan.nextInt();
	 int arr[] = new int[arrsize];
	 for (int i = 0; i < arr.length; i++)
		 arr[i] = scan.nextInt();
	 LinkedHashSet<Integer> lhs = ALT_TAB(alt_tab, arr);
     tc--;
	System.out.println(lhs.toString());
	 }
 }
   static LinkedHashSet<Integer> ALT_TAB(int alt_tab, int[] arr) {
	   LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
	   for (int i = 1; i <=arr.length; i++) {
      	if(i==alt_tab) {
      		lhs.add(arr[i-1]);
      	break;
      	}
       }
     for (Integer i : arr) 
  		lhs.add(arr[i-1]);
   return lhs;
   }
}