package com.sd.logics;

public class Answer {
	private static String sentence = "iamoncloudnine";
public static void main(String[] args) {
	int [] arr = {9,6,8,1,5,4,3,0,7};
	int wrapA = arr[6]; int wrapB = arr[8]; int wrapC = arr[7];
	System.out.println(sentence.substring(wrapA, sentence.lastIndexOf('n')).substring(wrapC,wrapB));
}
}
