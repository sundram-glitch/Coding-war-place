package   com.sd.logics;
import java.util.*;
public class DronesNpipes {
 public static void main(String[] args) {
  Scanner scan = new Scanner(System.in);
  int N = scan.nextInt();
  int arr[] = new int[N];
  for (int i = 0; i < arr.length; i++)
	  arr[i] = scan.nextInt();
  check(arr);
 }
  private static void check(int[] arr) {
  List<Integer> list = new ArrayList<Integer>();
  for (int i = 0; i < arr.length; i++) 
	  list.add(arr[i]);
  for (int i = 0; i < list.size()-1; i++) {
	if(list.get(i+1)>list.get(i)) { list.remove(i+1); i--;}; 
  }
  for (Integer integer : list) 
	  System.out.print(integer+" ");
  }
}//sd
