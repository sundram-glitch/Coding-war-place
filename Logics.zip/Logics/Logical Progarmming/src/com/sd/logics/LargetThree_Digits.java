package com.sd.logics;

import java.util.Scanner;

public class LargetThree_Digits {
 public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int  n = scan.nextInt();
	String maxNum= "";
	int temp = 0;
	String str = Integer.toString(n);
	for (int i = 0; i < str.length(); i++) {
	  for (int j = i; j <3+i && j< str.length(); j++) {
		  maxNum += str.charAt(j);
	   }
	  if((Integer.parseInt(maxNum))>temp) 
		  temp = Integer.parseInt(maxNum);
	  maxNum ="";
	}
	System.out.println(temp);
}
}
