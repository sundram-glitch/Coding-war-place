package com.sd.logics;

import java.util.Arrays;
import java.util.Scanner;

public class Kth_Smallest_ele {
  public static void main(String[] args) {
	Scanner sc  = new Scanner(System.in);
	int size = sc.nextInt();
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++)
		arr[i] = sc.nextInt();
	int l = 0;
	int r = size-1;
	int K = sc.nextInt();
	kthSmallest(arr,l,r,K); 
}

   static void kthSmallest(int[] arr, int l, int r, int k) {
	   Arrays.sort(arr);
       for(int i = 0; i < arr.length ; i++){
       System.out.print(arr[i]);
       if(i<arr.length-1) System.out.print(" ");
   }
 }
}