package com.sd.logics;

import java.util.*;

public class Check_Missing_Char {
  public static void main(String[] args) {
  ArrayList<Character> al = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	String Transstr = sc.next();
	String RecStr = sc.next();
	if(Transstr.equals(RecStr))
		System.out.println(RecStr);
	else {
		for (int i = 0; i < Transstr.length(); i++) {
			if(RecStr.contains(Transstr.charAt(i)+""))continue;
			else al.add(Transstr.charAt(i));
		}
	}
	System.out.println(al);
}
}
