package com.sd.logics;

import java.util.*;
import java.util.Map.Entry;

public class Count_String_No {
  public static void main(String[] args) {
	  Map<String, Integer> map = new LinkedHashMap<>();
	  ArrayList<String> al =  new ArrayList<String>();
	  Scanner sc = new Scanner(System.in);
	  String str = sc.nextLine();
	  String strArr [] = str.split(" ");
	  int N = sc.nextInt();
	  for (int i = 0; i < strArr.length; i++) 
		  map.put(strArr[i], map.getOrDefault(strArr[i], 0)+1);
	  for (Entry<String, Integer> entry : map.entrySet())
		if(entry.getValue()>=N)al.add(entry.getKey());
	  System.out.println(al.toString());
	  sc.close();
   }
}
