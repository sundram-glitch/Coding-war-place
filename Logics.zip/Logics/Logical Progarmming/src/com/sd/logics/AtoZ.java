package com.sd.logics;

public class AtoZ {
  public static void main(String[] args) {
	  int i , j = 1 , k = 1;
	  for (i = 1; i < 10; i++) {
		  System.out.print(i+" ");
		for (j = k; j <=26; j++) {
			if(j==(3*i)+1) break;
			System.out.print((char)(64+j));
		}
			k = j;
		System.out.println();
	  }
  }
}
