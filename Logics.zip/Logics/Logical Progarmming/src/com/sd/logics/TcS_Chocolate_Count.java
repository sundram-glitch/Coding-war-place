package com.sd.logics;

import java.util.*;

public class TcS_Chocolate_Count {
  public static void main(String[] args) {
	Scanner get = new Scanner(System.in);
	int N = get.nextInt();
	int [] arr=new int[N];
	for (int i = 0; i < arr.length; i++)
		arr[i] = get.nextInt();
	System.out.print(check_Empty(arr));
}

private static List check_Empty(int[] arr) {
	LinkedList<Integer> list = new LinkedList<Integer>();
	for (int i = 0; i < arr.length; i++) 
		if(arr[i]!=0) list.add(arr[i]);
	for (int i = 0; i < arr.length; i++)
	    if(arr[i]==0)list.add(arr[i]);
		return list;
}
}
