package com.sd.logics;

import java.util.Scanner;

public class Number_Validate {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String str = scan.next();
	char delimeter = scan.next().charAt(0);
	groupDigits(str,delimeter);
  }
  static void groupDigits(String str, char delimeter) {
  if(str.charAt(0)=='0') { System.out.print("invalid"); return;}
  else if(str.length()<4) { System.out.print(str); return;}
  StringBuffer finalStr = new StringBuffer();
  int count = 0;
  for (int i = 0; i <str.length()/2; i++) {
	  count++;
  for (int j = i; j < count+i; j++) {
  finalStr.append(str.charAt(j));
  } 
  finalStr.append(" ");
  }
  str = String.valueOf(finalStr);
  str = str.replaceAll(" ", String.valueOf(delimeter));
  System.out.println(str);
 }
}