package com.sd.logics;

public class MIn_Arr {
 public static void main(String[] args) {
	int arr[] = {23,45,56,234};
	int  min = 0 , temp =23;
	for (int i = 0; i < arr.length-1; i++) {
		
   
	}
	System.out.println(temp);
 }
}
