/*package com.sd.logics;

import java.util.Scanner;

public class Point2D{
	static Scanner scan = new Scanner(System.in);
  public static void main(String[] args) {
   Point2D p  = new Point2D();
   int N = scan.nextInt();
   int[]  A = new int[N];
   for (int i = 0; i < A.length; i++)
	   A[i] = scan.nextInt();
  // Point2D[] p2 = A;
   //System.out.println(p.length);
  }
  public int solution(Point2D[] a) {
	  int count =0;
	  for (int i = 0; i < A.length; i++) {
		for (int j = 0; j < A.length; j++) {
			if(A[i]!=A[j+1] && A[i]!=A[j+2]) count++;
		}
	}
	return count;
	  
  }
}*/
