package com.sd.logics;

import java.util.*;

public class Maximum_Sum_Of_Product {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int N = scan.nextInt();
	Integer arr[] = new Integer[N];
	for (int i = 0; i < arr.length; i++) 
		arr[i] = scan.nextInt();
	maxSalesum(arr);
    }

    private static void maxSalesum(Integer[] arr) {
    List<Integer> list = new ArrayList<Integer>();    
    for (int i = 0; i < arr.length; i++) 
    	list.add(arr[i]);
    Integer temp = 0, max_no =0;
    for (int j = 0; j <2; j++) {
    temp=list.get(0);
	for (int i = 0; i < list.size()-1; i++) {
		if(list.get(i+1)>temp) temp = list.get(i+1); 
	}
	max_no += temp; 
    list.remove(temp);
    }
    System.out.println(max_no);
    }
}
