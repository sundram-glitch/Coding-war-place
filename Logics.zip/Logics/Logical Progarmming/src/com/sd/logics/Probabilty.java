package com.sd.logics;

import java.util.*;

public class Probabilty {
 public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	//int T = scan.nextInt();
	//while(T!=0) {
	int N = scan.nextInt();
	//int M = scan.nextInt();
	int arr [] = new int[N];
	for (int i = 0; i < arr.length; i++)
     arr[i] = scan.nextInt();
	System.out.println(check(arr));
	//T--;
	//}
 }

 static int check(int[] arr) {
	int count = 0;
    for (int i = 0; i < arr.length; i++)
	for (int j = i; j < arr.length-1; j++)
      if(arr[i]!=arr[j+1]) count++; 		
    return count;
 }
}
