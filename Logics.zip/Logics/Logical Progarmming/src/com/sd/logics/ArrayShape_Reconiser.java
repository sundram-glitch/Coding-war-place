package com.sd.logics;

public class ArrayShape_Reconiser {
    static int [] arr;
    static int newArr[] = new int [100]; 
    static int arrayShape(int arr[]) {
    if(arr.length!=0)
     while(arr.length-1!=0) {
    
     }
    	return 0;
    }
	public static void main(String[] args) {
   
}
}
