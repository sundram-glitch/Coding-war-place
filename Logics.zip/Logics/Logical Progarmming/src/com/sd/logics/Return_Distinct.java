package com.sd.logics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Return_Distinct {
  static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
	int size  = sc.nextInt();
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++) 
		arr[i] = sc.nextInt();
	System.out.println(solution(arr));
    }
	  static int solution(int[] arr) {
	ArrayList<Integer> al = new ArrayList<Integer>();
	for (int i = 0; i <arr.length; i++)
		al.add(arr[i]);
	Collections.sort(al); int i  = 0;
	for (i = 0; i < al.size(); i++) {
		if(al.contains(al.get(i)<0?(al.get(i)-1):(al.get(i)+1)))
		continue;
		else break;
	}
		return (al.get(i)+1)<0?1:(al.get(i)+1); 
  
  }
}
