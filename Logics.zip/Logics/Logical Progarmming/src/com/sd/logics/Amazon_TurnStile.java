package com.sd.logics;

import java.util.List;
import java.util.Scanner;

public class Amazon_TurnStile {
  public static void main(String[] args) {
	 Scanner get = new Scanner(System.in);
	 int numCustomers = get.nextInt();
	 int[] arrTime = new int[numCustomers];
	 for (int i = 0; i < args.length; i++) 
		 arrTime[i] = get.nextInt();
	 int direction [] = new int[numCustomers];
	 checkTurnstle(numCustomers, arrTime, direction);
  }
  public static List<Integer> checkTurnstle(int numCustomers,int [] arrTime,int[] direction) {
	for (int i = 0; i < arrTime.length; i++) {
		
		
	}
	  return null;
  }
}
