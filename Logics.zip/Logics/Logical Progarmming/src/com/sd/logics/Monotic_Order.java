package com.sd.logics;

import java.util.Scanner;

public class Monotic_Order {
	    public static boolean isMonotonic(int[] nums) {
	    	if(nums.length==1) return true;
	        boolean flag1 = false;
	        boolean flag2 = false;
	        //increasing order check
	        for(int i =0; i< nums.length-1; i++){
	             if(nums[i]<=nums[i+1]) flag1 = true; 
	             else{
	             flag1 = false;
	             break;
	             }
	        }
	        //Decreasing order
	        for(int i = 0; i<nums.length-1; i++){
	            if(nums[i]>=nums[i+1]) flag2 = true;
	            else{
	                 flag2 = false;
	                 break;
	            }
	        }
	        return flag1 | flag2 ? true : false;
	    }
	    public static void main(String[] args) {
	    	Scanner sc = new Scanner(System.in);
	    	int N = sc.nextInt();
	    	int arr[] = new int[N];
	    	for (int i = 0; i < arr.length; i++) 
	    		arr[i] = sc.nextInt();
			System.out.println(isMonotonic(arr));
		}
}
