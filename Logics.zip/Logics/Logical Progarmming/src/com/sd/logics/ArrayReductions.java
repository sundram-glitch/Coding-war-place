package com.sd.logics;

import java.util.*;

public class ArrayReductions {
  public static void main(String[] args) {
   Scanner scan = new Scanner(System.in);
   List<Integer> list = new ArrayList<Integer>();
   int N = scan.nextInt();
   for (int i = 0; i < N; i++) 
   list.add(scan.nextInt()); 
   int sum = 0;
   for (int i = 0; i<list.size()-1; i++) {
	int first = list.get(i);
	int sec = list.get(i+1);
	int temp = first+sec;
    sum += temp;
    list.remove((Object)first);list.remove((Object)sec);
    list.add(temp);
   i=-1;
   }
   System.out.println(sum+" "+list);
}
}
