package com.sd.logics;

import java.util.Scanner;

public class Maximum_No_Guest_TcS {
 public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int T = scan.nextInt();
	int sum = 0, max = Integer.MIN_VALUE;
	int  E [] = new int[T];
	int  L [] = new int[T];
	for (int i = 0; i < L.length; i++)
		E[i] = scan.nextInt();
	for (int i = 0; i < L.length; i++) 
		L[i] = scan.nextInt();
	for (int i = 0; i < L.length; i++) {
		sum += E[i]-L[i];
		if(sum >max)
			max = sum;
	}
	System.out.println(sum);
}
}
