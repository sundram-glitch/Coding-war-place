/*
 * package com.sd.logics;
 * 
 * import java.util.*; public class Max_Product_Sum { public static void
 * main(String[] args) { Scanner sc = new Scanner(System.in); ArrayList<Integer>
 * al = new ArrayList<Integer>(); int N = sc.nextInt(); for (int i = 0; i < N;
 * i++) al.add(sc.nextInt()); int max1 = Collections.max(al);
 * al.remove((Object)max1); int max2 = Collections.max(al);
 * System.out.println(max1+max2); } }
 */