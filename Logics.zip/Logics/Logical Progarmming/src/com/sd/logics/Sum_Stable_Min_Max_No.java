package com.sd.logics;

import java.util.Scanner;

public class Sum_Stable_Min_Max_No {

	 public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int arr [] = new int[n];
		int newArr[] = new int[n];
		int  mode = 0  , count =0, initial =0;
		String temp = null;
		for (int i = 0; i < arr.length; i++) 
			arr[i] = scan.nextInt();
		for (int i = 0; i < arr.length; i++) {		
			temp = Integer.toString(arr[i]);
			if(temp.length()/2==0) {
		for (int j = 0; j < arr.length; j++) {
		for (int k = j+1; k < arr.length; k++) {	
            if(temp.charAt(j) == temp.charAt(k)  ) {
            	count++;
            	if(count == (temp.length()/2)) {
            	newArr[initial++] = arr[i];
            	}
            }
		}
		}
			}
		}
 	}
}
