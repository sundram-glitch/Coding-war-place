package com.sd.logics;

import java.util.Scanner;

public class Unit_Digit {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int N = sc.nextInt();
	
}
} 
