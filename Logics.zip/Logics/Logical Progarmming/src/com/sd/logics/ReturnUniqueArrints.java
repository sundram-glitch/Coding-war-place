package com.sd.logics;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class ReturnUniqueArrints {
public static void main(String[] args) {
	/*Scanner scn = new  Scanner(System.in);
	System.out.println("Enter No of integers you wants!!");
	int n = scn.nextInt();
	ArrayList<Integer> list = new ArrayList<Integer>();
	System.out.println("Enter N seprated Integers ");
	for (int i = 0; i < n; i++) 
	list.add(scn.nextInt());*/
	int a[]= {1,1,2,2,3,3,4,4,5,5};
    LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
    for (int i = 0; i < a.length; i++) lhs.add(a[i]);
    System.out.println(lhs);
    ArrayList<Integer> list = new 	 ArrayList<Integer>(lhs);
    for (int i = list.size()-1; i > 0; i--)
		System.out.println(list.get(i));
  }
}
