package com.sd.logics;

import java.util.*;

public class ELectronis_pair {
  public static void main(String[] args) {
	String str = new Scanner(System.in).next().toLowerCase();
	String newStr = "";
	char[] ch =str.toCharArray();
    for (int i = 0; i < ch.length-1; i+=2) {
        if((int)ch[i]> (int)ch[i+1]) newStr +=(char)ch[i];
		else newStr +=(char)ch[i+1];
	}
    if(ch.length%2==0) System.out.println(newStr);
    else System.out.println(newStr+ch[ch.length-1]);
  }
}
