package com.sd.logics;

import java.util.Scanner;

public class Sum_Nums {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int N = sc.nextInt();
	int div = N , mod = 0, sum = 0;
	while(div!=0) {
		mod = div%10;
		sum +=mod;
		div /= 10; 
	}
	System.out.println((char)(64+sum));
}
}
