package com.sd.logics;

import java.util.LinkedHashMap;
import java.util.Scanner;

public class Amazon_Duplicate_No_Occurance {
  public static void main(String[] args) {
   Scanner get = new Scanner(System.in);
	int N = get.nextInt();
	int findNo = get.nextInt();
   int arr[] =new int[N];
   for (int i = 0; i < arr.length; i++) 
	   arr[i] = get.nextInt();
 System.out.println(countOccurance(arr, findNo));
}

private static Integer countOccurance(int [] arr, int findNo) {
 LinkedHashMap<Integer, Integer> map = new LinkedHashMap<Integer, Integer>();
	for (int i = 0; i < arr.length; i++) 
	  map.put(arr[i], map.getOrDefault(arr[i], 0)+1);
	    return map.getOrDefault(findNo, 0);
}
}
