package com.sd.logics;

import java.util.*;
import java.util.Map.*;

public class Maximum_No_DIfference {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	Map<Integer, Integer> map = new TreeMap<>();
	Deque<Integer> stack = new ArrayDeque<Integer>();
	int N = scan.nextInt();
    Integer arr [] = new Integer[N];
	for (int i = 0; i < arr.length; i++) 
		arr[i] = scan.nextInt();
    for (Integer key : arr) 
		map.put(key , map.getOrDefault(key, 0)+1);
    System.out.println(map);
    int count = 0,k = 0, v = 0;
     
		for (Entry<Integer, Integer> value : map.entrySet()) {
			if(count==0 ) {
	            stack.push(value.getKey());
	            k = value.getKey();
	            v = value.getValue();
	            count++;
			}
			else if(k>value.getKey() || v>value.getValue()) {
				    stack.pop();
	                stack.push(value.getKey());
	            	k = value.getKey();
	            	v = value.getValue();
			}
		}
	
    count = 0;
   		for (Entry<Integer, Integer> val : map.entrySet()) {
			if(count==0) {
				v = val.getValue();
				stack.push(val.getKey());
				count ++;
			}
			else if (val.getValue() >=v) {
				stack.pop();
				stack.push(val.getKey());
				v = val.getValue();
			}
		}
    System.out.println(stack);
  }
}