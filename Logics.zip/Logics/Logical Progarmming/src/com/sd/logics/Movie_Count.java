package com.sd.logics;

import java.util.*;

public class Movie_Count {
 public static void main(String[] args) {
	List<Integer>  heights = new  ArrayList<>();
	Scanner scan = new Scanner(System.in);
	int N = scan.nextInt();
	int K = scan.nextInt();
	for (int i = 0; i < N; i++) 
		 heights.add(scan.nextInt());
	System.out.println(solve(N, K, heights));
 }

 static int solve(int N, int k, List<Integer> heights) {
  int whoCanWatch = N;
  List<Integer> list = heights;
  for (int i = 0; i < heights.size(); i++) {
	  int current = heights.get(i);
	for (int j = i+1; j < i+k && j < N ; j++) {
		if(current > heights.get(j)) continue;
		else { whoCanWatch--; break;}
	}
 }
  return whoCanWatch;
 }
}
