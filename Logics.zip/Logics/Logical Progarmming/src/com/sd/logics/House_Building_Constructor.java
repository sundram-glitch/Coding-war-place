package com.sd.logics;

import java.util.*;

public class House_Building_Constructor {
	public static void main(String[] args) {
		Scanner get = new Scanner(System.in);
		List<Integer> unique = new LinkedList<Integer>();
		int arr[][] = new int [3][3];
		int sum =0, temp =arr[0][0];
		for (int i = 0; i < arr.length; i++)
		for (int j = 0; j < arr.length; j++) 
			arr[i][j] = get.nextInt();
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				if(j<arr.length-1) {
				if(i ==0 && arr[i][j]<arr[i][j+1]) {
				if(j==0) temp= arr[i][j];					
				else if(arr[i][j]<temp) temp =arr[i][j];
				}
				else if(i ==1 && arr[i][j]<arr[i][j+1] && arr[i][j]!=temp)temp = arr[i][j];
			    else if(i==2 && arr[i][j]<arr[i][j+1] && arr[i][j]!=temp) temp = arr[i][j];
				}
				else {
				     	if(i ==0 && arr[i][j]<arr[i][j-1]) temp= arr[i][j];					
						else if(i ==1 && arr[i][j]<arr[i][j-1] && arr[i][j]!=temp)temp = arr[i][j];
						else if(i==2 && arr[i][j]<arr[i][j-1] && arr[i][j]!=temp) temp = arr[i][j];
				}
				}
			unique.add(temp);
				}
		System.out.println(unique);
       for (int num : unique) 
		sum += num;
	System.out.println(sum);
	}
}