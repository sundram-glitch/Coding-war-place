package com.sd.logics;

import java.util.Scanner;

public class DecimaltoBinary {
	public static void main(String[] args) {
		Scanner get = new Scanner(System.in);
		int a = get.nextInt();
		int arr[] = new int[10];
		for (int i = 0; i < arr.length && a!=0; i++ ,a= a/2) 
			arr[i] = a%2;
	for (int i = 0; i < arr.length; i++) 
		System.out.print(arr[i]);
	}
}
