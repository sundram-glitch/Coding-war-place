package com.sd.logics;

import java.util.*;

public class Min_Max_Wipro {
  public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
	 int N = sc.nextInt();
	 int arr[] = new int[N];
	 for (int i = 0; i < N; i++) 
		 arr[i] = sc.nextInt();
	 Arrays.sort(arr);
	 System.out.println(Arrays.toString(arr));
	 int temp1 = 0, his = 0;
	 boolean flag1 = true;
	 for (int i = 0; i < arr.length; i++) {
		 int count = 0;
		 for (int j = i+1; j < arr.length; j++) {
			if(arr[i] == arr[j] | arr[i]==his) {
				his =  arr[i];
				count ++;
				break;
		    }
		 }
		 if(count == 0 && flag1) {
			 temp1 = arr[i];
			 flag1 = false;
		 }
		 else if(count == 0 &&  arr[i]<temp1)temp1 = arr[i]; 
	}//outer for
	 boolean flag2 = true; int temp2 = 0, tempCount = 0;
	for (int i = 0; i < arr.length; i++) {
		int count = 0;
		for (int j = i+1; j < arr.length; j++)
			if(arr[i]==arr[j] && arr[i]>temp1) count++;
        if(count!=0 && flag2) {
        	temp2 = arr[i];
            tempCount = count;
        }
        else if(count >=tempCount && arr[i]<temp2) {
        	temp2 = arr[i];
            tempCount = count;
        }
	}
	 System.out.println(temp1-temp2);
	 sc.close();
  } 
}
