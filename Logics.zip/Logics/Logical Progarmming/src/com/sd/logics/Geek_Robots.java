package com.sd.logics;

import java.util.Scanner;

public class Geek_Robots {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	  String str1 = sc.next();
	  String str2 = sc.next();
	  System.out.println(moveRobots(str1, str2));
  }
  /*if(s1.lastIndexOf('A')==s2.lastIndexOf('A'))
    	return "Yes";
	    return "No";*/
    public static String moveRobots(String s1, String s2){
    //char ch1[] = s1.toCharArray();
    char ch2[] = s2.toCharArray();
    for (int i = 0; i < ch2.length/2; i++) {
		if(ch2[i]=='A') {
		    return "No";
		}
	}
    return "Yes";
    }
}
