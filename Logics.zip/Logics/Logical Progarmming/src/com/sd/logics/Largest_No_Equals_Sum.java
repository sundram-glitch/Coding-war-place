package com.sd.logics;

import java.util.Scanner;

public class Largest_No_Equals_Sum {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int N = scan.nextInt();
	int K = scan.nextInt();
	int arr[] = new int[N];
	for (int i = 0; i < arr.length; i++) 
		arr[i] = scan.nextInt();
	check(arr,K);
    }

    private static void check(int[] arr,int K) {
	 for (int i = 0; i < arr.length; i++) {
		for (int j = 0; j < arr.length-1; j++) {
			if(arr[i]+arr[j+1]==K) { 
		System.out.println(i+" "+(j+1));
		return;
			}
		}
	}
	 System.out.print(-1);
    }
}//Sundram Dubey