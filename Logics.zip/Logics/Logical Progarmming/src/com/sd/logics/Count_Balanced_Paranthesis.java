/*
 * package com.sd.logics;
 * 
 * import java.util.*; public class Count_Balanced_Paranthesis { public static
 * void main(String[] args) { Deque<Character> dq = new ArrayDeque<Character>();
 * String str = new Scanner(System.in).next(); int count = 0; for (int i = 0; i
 * < args.length; i++) { char ch1 = str.charAt(i); if(ch1 == '[' | ch1 == '{' |
 * ch1 == '(') { dq.push(ch1); continue; } switch(ch1) { case ')' : char ch2 =
 * dq.peek(); if(ch2!='{' | ch2!='[') { count++; dq.pop(); } break; case '}' :
 * char ch2 = dq.peek(); if(ch2!='{' | ch2!='[') { count++; dq.pop(); } break;
 * case ']' : char ch2 = dq.peek(); if(ch2!='{' | ch2!='[') { count++; dq.pop();
 * } break; case ')' : char ch2 = dq.peek(); if(ch2!='{' | ch2!='[') { count++;
 * dq.pop(); } break;
 * 
 * } } } }
 */