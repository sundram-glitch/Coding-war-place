package com.sd.logics;

import java.util.*;
public class Application_ID_Even_Odd {
  public static void main(String[] args) {
	int applicationID = new Scanner(System.in).nextInt();
  check(applicationID);
  }
  private static void check(int applicationID) {
  Stack<Integer> stack = new Stack<Integer>();
	  int mod = 0, div = applicationID, temp = 0;
	  while(div!=0) {
		mod = div%10;
		if(mod%2==0) {
			temp = mod+1;
			stack.push(temp);
		}
		else {
			temp = mod -1;
			stack.push(temp);
		}
		div /=10;
	}
	  System.out.println(stack.size());
	  int size = stack.size(); 
	  for (int i = 0; i < size; i++) {
		System.out.print(stack.pop());
	}
  }
}
