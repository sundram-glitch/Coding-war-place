package com.sd.logics;

import java.util.Scanner;

public class Count_Max_Possibilities {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter No ");
	int size  = scan.nextInt();
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++) 
		arr[i]=scan.nextInt();
	System.out.println(checkIndex(arr));
}
  public static int  checkIndex(int[] arr) {

	  int i =1; int num =0;
	  for ( i = 1; i < arr.length; i++) {
	  if(arr[arr.length-i] >=9) {
		  arr[arr.length-1] = 0;
		  continue;
	  }
	  else {  
	  num = arr[arr.length-i] ;
	  arr[arr.length-i] +=1;
	  System.out.println(arr[arr.length-i]);
	  break;
	  }
	}
	  return num;
  }
}
