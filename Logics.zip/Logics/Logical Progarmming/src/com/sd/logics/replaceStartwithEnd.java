package com.sd.logics;

import java.util.*;

public class replaceStartwithEnd {
 public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
	 ArrayList<Integer> al  = new ArrayList<Integer>();
	 int N = sc.nextInt();
	 int At = sc.nextInt();
	 int value = sc.nextInt();
	 for (int i = 0; i < N ; i++) al.add(sc.nextInt());
	 System.out.println(al);
	 al.add(At-1, value); //al.remove(At);
	 System.out.println(al);
	 
		 
}
}
