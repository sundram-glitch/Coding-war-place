package com.sd.logics;

import java.util.Scanner;
import java.util.Vector;

public class Alt_tab_collection {
  public static void main(String[] args) {
	 Scanner scan = new Scanner(System.in);
	  Vector<Integer>  vec= new Vector<Integer>();
	  int size = scan.nextInt();
	  int alt_tab = scan.nextInt();
	 for (int i = 0; i < size; i++) 
         vec.add(scan.nextInt());
	 System.out.print(vec.get(alt_tab-1));
	 vec.remove(alt_tab-1);
     for (int i = 0; i < vec.size(); i++)
    	 System.out.print(" "+vec.get(i));
  }
} 
