package com.sd.logics;

public class Difference_2_Maximum_Elements {
	
	     /* The function assumes that there are at least two
	       elements in array.
	       The function returns a negative value if the array is
	       sorted in decreasing order.
	       Returns 0 if elements are equal */
	static int maxDiff(int arr[])
	    {
	        int max_diff = 0;
	        System.out.println(max_diff);
	        int i, j;
	        for (i = 0; i < arr.length; i++)
	        {
	            for (j = i + 1; j < arr.length; j++)
	                if (arr[j] - arr[i] > max_diff)
	                    System.out.println(max_diff = arr[j] - arr[i]);
	        }
	        System.out.println();
	        return max_diff;
	    }
	    /* Driver program to test above functions */
	    public static void main(String[] args)
	    {
	        int arr[] = {1, 2, 90, 10, 110};
	        System.out.println("Maximum difference is " +maxDiff(arr));
	    }
	}