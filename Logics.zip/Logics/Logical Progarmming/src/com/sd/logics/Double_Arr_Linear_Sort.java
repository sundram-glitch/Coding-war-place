package com.sd.logics;

import java.util.Scanner;

public class Double_Arr_Linear_Sort {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int testCase = scan.nextInt();
		int temp  = 0 ;
	    int arr[][] = new int[3][5];
	    for (int i = 0; i < arr.length; i++)
			for (int j = 0; j < 5; j++) 
				arr[i][j]=scan.nextInt();
	    for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < 5; j++) {
				if(j<4 && arr[i][j] > arr[i][j+1] ) {
					temp = arr[i][j];
					arr[i][j] = arr[i][j+1];
				    arr[i][j+1] = temp;
				    j=-1;
				}
			}
		}
	    for (int i = 0; i < arr.length; i++) { 
			for (int j = 0; j < 5; j++) 
				System.out.print(arr[i][j]+", ");
	     System.out.println();
	    }
	}
	}
	/*3
	8 7 6 15 5
	1 1 1 15 5
	8 5 7 15 6
	*/
