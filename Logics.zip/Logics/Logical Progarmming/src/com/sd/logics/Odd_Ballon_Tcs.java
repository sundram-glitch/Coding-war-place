package com.sd.logics;

import java.util.*;

public class Odd_Ballon_Tcs {
  public static void main(String[] args) {
	Map<Character, Integer> list = new LinkedHashMap<Character, Integer>();
	Scanner scan  = new Scanner(System.in);
	int  n = scan.nextInt();
	char arr[] = new char[n];
	for (int i = 0; i < arr.length; i++)
		arr[i] = scan.next().charAt(0);
	for (char c : arr) 
	list.put(c, list.getOrDefault(c, 0)+1);	
    for (char d : arr){
    	if(list.get(d)%2==1){ System.out.print(d); return;}
    }
    System.out.println("No odd colors");
  }
}
