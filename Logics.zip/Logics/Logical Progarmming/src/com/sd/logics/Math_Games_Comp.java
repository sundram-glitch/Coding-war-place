package com.sd.logics;

import java.util.ArrayList;
import java.util.Scanner;

public class Math_Games_Comp {
  public static void main(String[] args) {
  ArrayList<Integer> al = new ArrayList<Integer>();
	  Scanner sc = new Scanner(System.in);
	int initial =  sc.nextInt();
	int next =  sc.nextInt();
	int jumpStep =  sc.nextInt();
	int temp = initial;
    for (int i = 0; i < jumpStep; i++) {
    	al.add(temp);
        initial += next;
    	temp = initial;
    }
    for (int i = 0; i < al.size(); i++)
    System.out.print(al.get(i)+" ");
  }
}
