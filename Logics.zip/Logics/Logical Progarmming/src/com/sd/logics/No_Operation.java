package com.sd.logics;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class No_Operation {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	List<Integer> list = new LinkedList<Integer>();
	int n = scan.nextInt();
    int square = n*n;
    int cube =  n*n*n;
    int div  = n;
    int mod = 0;
    while(div!=0) {
    mod =div%10;
    list.add(mod);
    div /=10;
    }	
    System.out.println("Square Root is :"+square);
    System.out.println("Cude Root is :"+cube);
    System.out.println("Reverse of N :"+list);
}
}
