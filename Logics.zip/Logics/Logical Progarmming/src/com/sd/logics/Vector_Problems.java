package com.sd.logics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Vector_Problems {
 public static void main(String[] args) {  
	 Scanner scan = new Scanner(System.in);
	 int N = scan.nextInt();
	 int []arr = new int[N];
	 for (int i = 0; i < arr.length; i++) 
		 arr[i] = scan.nextInt();
	 int k = scan.nextInt();
	 System.out.println(addingCost(N,arr,k));
}

    static int addingCost(int n, int[] arr, int k) {
	int minCost = 0,i = 0;
    if(n==1)return arr[0];
	else if(n%2!=0) {
		for ( i = 0; i < arr.length/2-1; i+=2) 
			minCost  = k * (arr[i]+arr[i+1]);
		  return  minCost = k *(arr[i]+minCost);
	}
	for (int j = 0; j < arr.length; j+=2) 
		minCost  = k * (arr[i]+arr[i+1]);
    List<Integer> list = new  ArrayList<Integer>();
    for (int j = 0; j < arr.length; j++) 
    	list.add(arr[i]);
    int sum = 0;
    Iterator it = list.iterator();
    while(it.hasNext()) {
    	sum +=(Integer) it.next();
    	minCost *=sum;
    }
    	
    return minCost;
    }
}