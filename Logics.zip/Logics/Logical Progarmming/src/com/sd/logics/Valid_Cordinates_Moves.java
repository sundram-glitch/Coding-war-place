package com.sd.logics;

import java.util.Scanner;

public class Valid_Cordinates_Moves {
  public static void main(String[] args) {
	 Scanner sc   = new Scanner(System.in);
	 int T = sc.nextInt();
	 while(T!=0) {
	 int X = sc.nextInt(); int Y = sc.nextInt();
	 if(X==Y) System.out.println("Yes");
	 else if(Math.abs(X-Y)%2==0)System.out.println("Yes");
	 else System.out.println("No");
		 T--;
	 }
  }
}
