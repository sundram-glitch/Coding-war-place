package com.sd.logics;

import java.util.Scanner;

public class Likes_Dislikes {
 
	public static void main(String[] args) {
     Scanner scan = new Scanner(System.in);
     int A = scan.nextInt();
     int P = scan.nextInt(); 
     int div1 =A , mode1 = 0 , div2 = 0, mode2 = 0, count =0;;
     while(div1 != 0) {
    	 mode1 = div1%10;
    	 mode2 = div2%=10;
    	 if(mode1 != mode2) 
    		 count++;
         div1 /=10;
         div2 /=10;
     }
     System.out.println(count);
	}
}
