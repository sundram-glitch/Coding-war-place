package com.sd.logics;

import java.io.*; // for handling input/output
import java.util.*; // contains Collections framework

// don't change the name of this class
// you can add inner classes if needed
class Main {
	public static void main (String[] args) {
                      // Your code here
    Scanner scn=new Scanner(System.in);
    System.out.println("Enter tEST Case ");
    int t = scn.nextInt();
    int arr[][] = new int[t][t*3];
    for(int i=0;i<t;i++)
    for(int j=0; j<3; j++)
    arr[i][j]=scn.nextInt();
    for(int i=0; i < t ;i++)
    System.out.println(Math.max(Math.abs((arr[i][0]-arr[i][2])),Math.abs(arr[i][1]-arr[i][2])));
    }
}
