package com.sd.logics;

public class MaxDiffInArrays {
  public static void main(String[] args) {
  //initialize arrays with positive values
	  int arr[]=new int[] {5,0,10,2,3,6,8,1,12,7};
  //get the size of array
	  int n = arr.length;
	  System.out.print(MaxDifference(n,arr));
  }

    private static int MaxDifference(int n,int[] arr) {
	int max_diff = Integer.MIN_VALUE;
	for(int i =1; i<n;i++) {
	//for each pair we calculate the difference
	int curr_diff = Math.abs(arr[i]-arr[i-1]);
	//Update max_diff if current pair value is the greatest till now.
	max_diff = Math.max(max_diff, curr_diff);
	}
	return max_diff;
    }
}
