package com.sd.logics;

import java.util.Scanner;

public class Upper_LowerCase {
 public static void main(String[] args) {
   System.out.println("                                                            Start");
  Scanner sc = new Scanner(System.in);
  String str = sc.nextLine();
  String strArr[] = str.split(" ");
  str = "";
  //Print given string in upper letters
  for (int i = 0; i < strArr.length; i++) 
	  System.out.print(strArr[i].toUpperCase()+" ");
  System.out.println();
  //Print given string in lower letters
  for (int i = 0; i < strArr.length; i++) 
	  System.out.print(strArr[i].toLowerCase()+" ");
  System.out.println();
  //Print given string first letter in lower letters
   for (int i = 0; i < strArr.length; i++) {
	   if((int)strArr[i].charAt(0)>=90) {
	   char ch = (char) ((char) (((int)strArr[i].charAt(0))) -(32));
	   str +=ch;
	   for (int j = 1; j < strArr[i].length(); j++)
	   str+=(char)strArr[i].charAt(j);
	   str +=" ";
	   }
	   else{
		   char ch = (char) ((char) (strArr[i].charAt(0))-(32));
		   str +=ch;
		   for(int j = 1; j < strArr[i].length(); j++)
			   str+=(char)strArr[i].charAt(j);
		   str +=" ";
	   }
	 }
   System.out.println(str.trim());
  }
}