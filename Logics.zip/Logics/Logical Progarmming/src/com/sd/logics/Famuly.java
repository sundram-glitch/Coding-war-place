package com.sd.logics;

import java.util.Scanner;

public class Famuly {
	 public static void main(String[] args) {
	 Scanner scn = new  Scanner(System.in);
	 System.out.println("Enter ");
		 int N = scn.nextInt();
		 int x = scn.nextInt();
		 int arr[] = new int[N];
		 for (int i = 0; i < arr.length; i++)
			 arr[i] = scn.nextInt();
	     System.out.print(check(arr,x)); 
	}

	private static int check(int[] arr,int x) {
	int count =0;
		for (int i = 0; i < arr.length; i++) {
		if(arr[i]==-1) {
			return 1;
		}
		if(arr[i]==-1)
			count++;
	}
		return count;
	}
	 
}
