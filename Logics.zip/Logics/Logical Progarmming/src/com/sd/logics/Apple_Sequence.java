package com.sd.logics;

import java.util.Scanner;

public class Apple_Sequence {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
	  int N = sc.nextInt();
	  int M = sc.nextInt(); 
	  String str = sc.next();
	  System.out.println(appleSequence(N, M, str));
     }
  public static int appleSequence(int N, int M, String arr){
   	  int count = 1, op = 1;
	  char chArr[] = new char[N];
	  for (int i = 0; i < chArr.length; i++) 
		  chArr[i] = arr.charAt(i);
	  for (int i = 0; i < chArr.length && count<=M; i++) {
		if(chArr[i]=='O') {
			chArr[i] = 'A';
		  count++;
		}
	  }
	  for (int i = 0; i < chArr.length-1; i++)
		if(chArr[i] == chArr[i+1])op++;
	  return op;
}
}
