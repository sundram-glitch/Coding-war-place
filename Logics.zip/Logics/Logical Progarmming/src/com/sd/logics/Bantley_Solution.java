package com.sd.logics;

import java.util.*;

public class Bantley_Solution {
  public static void main(String[] args) {
	 Scanner sc  = new Scanner(System.in);
	 String  str = sc.next();
	 System.out.println(solution(str));
  }
   static boolean solution(String str) {
  	LinkedList<Character> list = new LinkedList<>();
  	Stack<Character>  st = new Stack<Character>();
  	if(!str.contains("b")) return true;
  	else if(!str.contains("a")) return true;  			
  	char temp = 'a'; boolean res = true; 
	   for (int i = 0; i < str.length(); i++)
			st.push(str.charAt(i));
 	  	return st.peek()=='a'?false:true;
   }
}
