package com.sd.logics;

public class Returnreverse {

	
	public static void main(String[] args) {
		int a[] = {10,9,8,7,6,5,4,3,2,1};
		int arr[]=ArrReverse(a);
		for (int i = 0; i < arr.length; i++)
		System.out.println(arr[i]);
	}

	private static int[] ArrReverse(int[] a) {
		int l = a.length;
		int arr[]=new int[a.length];
		for (int i = 0; i < a.length; i++)
	    arr[i]=a[--l];
		return arr;	
	}
}
