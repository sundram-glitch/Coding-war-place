package com.sd.logics;

import java.util.*;

public class RegularSequence {
   public static void main(String[] args) {
	  String str  = new Scanner(System.in).nextLine();
	  int val1, val2;
	  LinkedHashSet<Character> set = new LinkedHashSet<Character>(); 
      for (int i = 0; i < str.length()-1; i++) {
    	if(str.charAt(i)!=' ') {
	     val1 = (int)str.charAt(i);
	     val2 = (int)str.charAt(i+1);
    	}
    	else {
    		set.add(' ');
      		continue;
    	}
    	if((val1+1) == val2) {
    		set.add((char) val1);
    		set.add((char) val2);
    	}
    	else if(val2!=' ') break;
    	else continue;
	}
      String strr="";
      for (Character character : set) 
      //strr +=character.charValue();
      strr +=String.valueOf(character);
      System.out.println(strr.trim());
  }
}
