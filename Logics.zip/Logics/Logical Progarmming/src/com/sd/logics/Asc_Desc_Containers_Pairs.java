package com.sd.logics;

import java.util.*;
public class Asc_Desc_Containers_Pairs {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int N = scan.nextInt();
	Integer  arr[] = new Integer[N];
	for (int i = 0; i < arr.length; i++)
		arr[i] = scan.nextInt();
	Checksum(arr);
    }

    private static void Checksum(Integer[] arr) {
    int temp = 0;
    List<Integer> list1 = Arrays.asList(arr);
    Collections.sort(list1);
       Arrays.sort(arr);
    for (int i = arr.length-1 , j=0; i >=arr.length/2 && j <=arr.length/2; i--
    		,j++)
	System.out.println(list1.get(i)+" "+arr[j]);
 }
}