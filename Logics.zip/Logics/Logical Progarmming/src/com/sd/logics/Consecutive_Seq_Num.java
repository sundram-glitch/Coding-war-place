package com.sd.logics;

import java.util.*;

public class Consecutive_Seq_Num {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int N = sc.nextInt();
	int arr[] = new int[N];
	    for (int i = 0; i < arr.length; i++) 
		   arr[i] = sc.nextInt();
	    int count = 0;
	    boolean flag = false;
	    ArrayList<Integer> al = new ArrayList<Integer>();
	    for (int i = 0; i < arr.length-1; i++) {
			if(arr[i]+1==arr[i+1]) {
		 		al.add(arr[i]);
		 		flag = true; 
		 		count ++;
		 		continue;
			}
			else if(count!=0 && flag) {
				al.add(arr[i]);
				flag = false;
			}
	    }
	    System.out.println(al);
 }
}
