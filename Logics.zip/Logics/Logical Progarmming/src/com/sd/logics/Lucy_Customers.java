package com.sd.logics;

import java.util.*;

public class Lucy_Customers {
  public static void main(String[] args) {
	ArrayList<Integer> al = new ArrayList<Integer>();
	  Scanner sc = new Scanner(System.in);
	int token = sc.nextInt();
	int fib1 = 1,fib2 = 1, fib3 = 0, i=0; 
	while(i<=token) {
		al.add(fib1);
		fib3 = fib1+fib2;
		fib1 = fib2; fib2=fib3;
		i++;
	}
	System.out.println(al.get(token-1));
}
}
