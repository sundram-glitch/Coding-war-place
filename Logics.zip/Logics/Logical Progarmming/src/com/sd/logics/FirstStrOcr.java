package com.sd.logics;
import java.util.*;
public class FirstStrOcr {
	static int FirstUniqueChar(String s) {
		LinkedHashMap<Character, Integer> count = new LinkedHashMap<Character, Integer>();
		 int n = s.length();
		 for (int i =0; i<n ;i++)
		 count.put(s.charAt(i),count.getOrDefault(s.charAt(i), 0)+1);
		 System.out.println(count);
		 System.out.println(count.get(s.charAt(4)));
		    for (int i = 0; i < n; i++) 
	    	if(count.get(s.charAt(i))==1) return i;
	     	 return -1;
	}
	public static void main(String[] args) {
		java.util.Scanner  scn = new java.util.Scanner(System.in);
		String str = scn.next();
		System.out.println(FirstUniqueChar(str));
	}
}
