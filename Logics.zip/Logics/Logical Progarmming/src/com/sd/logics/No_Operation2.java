package com.sd.logics;

import java.util.*;

public class No_Operation2 {
  public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	List<Integer> list1 = new LinkedList<Integer>();
	List<Integer> list2 = new LinkedList<Integer>();
	Map<Integer, Integer> map1 = new TreeMap<Integer, Integer>();
	Map<Integer, Integer> map2 = new TreeMap<Integer, Integer>();
	Set<Integer> set1 = new TreeSet<Integer>();
	Set<Integer> set2 = new TreeSet<Integer>();
	int N1 = scn.nextInt();
	int N2 = scn.nextInt();
	int div1 = N1, mod1 = 0;
	int div2 = N2, mod2 = 0;
	while(div1!=0) {
		mod1 = div1%10;
		list1.add(mod1);
		div1 /=10;
		mod2 = div2%10;
		list2.add(mod2);
		div2 /=10;
	}
	Collections.sort(list1);
	Collections.sort(list2);
	System.out.println(list1+"\n"+list2);
	for (Integer key : list1)
		map1.put(key, map1.getOrDefault(key, 0)+1);
	for (Integer key : list2)
		map2.put(key, map2.getOrDefault(key, 0)+1);
	for(Integer key : map2.keySet()) {
		if(map1.containsKey(key))
	      System.out.print(key);// Common No
	}
	System.out.println();
	for (Integer val : list1) 
		if(val%2==0) set1.add(val);
	for (Integer val : list2)
		if(val%2==0) set1.add(val);
	System.out.println(set1);//even
	for (Integer val : list1) 
		if(val%2!=0) set2.add(val);
	for (Integer val : list2)
		if(val%2!=0) set2.add(val);
	System.out.println(set2);//odd
}
}
