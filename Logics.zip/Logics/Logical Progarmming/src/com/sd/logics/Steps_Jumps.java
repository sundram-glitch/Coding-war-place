package com.sd.logics;

import java.util.Scanner;

public class Steps_Jumps {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int size = scan.nextInt();
	int arr[] = new int[size];
	for (int i = 0; i < arr.length; i++)
		arr[i] = scan.nextInt();
	System.out.println(arr.length);
	int N=arr.length-1, steps=0;
	while(N!=0) {
		if(arr[N]%2==0) {
			N -=1;
		steps++;
		}
		else {
			N /=2;
			steps++;
		}
		}
	System.out.print(steps);
  }
}
