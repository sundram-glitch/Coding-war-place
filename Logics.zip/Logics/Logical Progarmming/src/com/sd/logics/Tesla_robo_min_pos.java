package com.sd.logics;

import java.util.Scanner;

public class Tesla_robo_min_pos {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	
}
}
