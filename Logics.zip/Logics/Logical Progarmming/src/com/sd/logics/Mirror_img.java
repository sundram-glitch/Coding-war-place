package com.sd.logics;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Mirror_img {
  public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int N = scan.nextInt();
	while(N!=0) {
		int mirr = scan.nextInt();
		String str = Integer.toString(mirr);
		/*Pattern p = Pattern.compile("[13690]");
		Matcher m = p.matcher(str);*/
	boolean flag = Pattern.matches("[^2343]", str);
	if(flag)System.out.print(1);
	else System.out.print(0);
	N--;
	}
  }
}
