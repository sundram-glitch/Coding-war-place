package com.sd.logics;

import java.util.Scanner;

public class Math_Challenge {
  public static void main(String[] args) {
 	mathChallenege(new Scanner(System.in).nextInt());
  }
  static void mathChallenege(int num) {
	  String temp = String.valueOf(1);
		     temp += String.valueOf(1);
	   if(1*1==num) {
		   System.out.println(temp.length());
	   return;
	   }
	   boolean flag = true;
		for (int i = 1; i <num/2; i++) {
	    for (int j = 2; j <=num; j++) {
	    String str = String.valueOf(i);
	    str += String.valueOf(j);
	    if(i*j==num && flag) {
			  temp = String.valueOf(i);
			  temp += String.valueOf(j);
			  flag = false;		      
		  }
		  else if(i*j==num && str.length()<temp.length()) {
			  temp = String.valueOf(i);
	    temp += String.valueOf(j);
	    }
	   }
	   }
		System.out.println(temp.length());
  }
}
