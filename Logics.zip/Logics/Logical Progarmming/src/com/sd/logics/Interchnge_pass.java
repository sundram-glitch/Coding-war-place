package com.sd.logics;

import java.util.*;

public class Interchnge_pass {
  public static void main(String[] args) {
   Scanner sc = new Scanner( System.in);
   ArrayList<Integer> al = new ArrayList<Integer>();
   ArrayList<Integer> al1 = new ArrayList<Integer>();
   int N = sc.nextInt(); int temp1 = 0, temp2 = 0;
   for (int i = 0; i < N; i++) 
	   al.add(sc.nextInt());
   int startPoint = sc.nextInt();
   int endPoint = sc.nextInt();
   for (int i = 0; i < startPoint; i++)
	al1.add(al.get(i));
   for (int i = endPoint; i >=startPoint ; i--) 
	   al1.add(al.get(i));
   System.out.println(al1);
  }  
}
