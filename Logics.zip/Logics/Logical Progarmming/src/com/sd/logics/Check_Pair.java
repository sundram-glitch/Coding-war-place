package com.sd.logics;

import java.util.Scanner;

public class Check_Pair {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int N = sc.nextInt();
	int  arr [] = new int[N];
	for (int i = 0; i < arr.length; i++) 
		arr[i]  = sc.nextInt();
	for (int i = 0; i < arr.length; i++) {
		int count = 0;
		int j = 0;
		for (j = i+1; j < arr.length-1; j++)
			if(arr[i]==arr[j]) {
				count++;
			break;
			}
		if(count==1) System.out.print("["+arr[i]+""+arr[i+1]+"]");
	}
  }
}
