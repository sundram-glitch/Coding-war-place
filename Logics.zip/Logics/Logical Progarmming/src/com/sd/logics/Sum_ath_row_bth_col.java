package com.sd.logics;

import java.util.Scanner;

public class Sum_ath_row_bth_col {
	static	int n,m,row,col,sum;
 public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	n=scn.nextInt();
	m=scn.nextInt();
	int [][]arr = new int[m][n];
	
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			arr[i][j]=scn.nextInt();

	row = scn.nextInt();
	col=scn.nextInt();
	
	for (int i = 0; i < arr.length; i++) 
		sum +=arr[row][i];
	System.out.println(sum);
	for (int i = 0; i < arr.length; i++) 
		sum+=arr[i][col];
    System.out.println(sum);
	System.out.println(sum -=arr[row][col]);
	scn.close();
 }
}
