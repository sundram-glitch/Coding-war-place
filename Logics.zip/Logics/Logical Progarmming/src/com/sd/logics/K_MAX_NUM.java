package com.sd.logics;

import java.util.*;
//even sum of K numb!!
public class K_MAX_NUM {
	
    static int solution(int arr[],int K){
        if (K > arr.length)return -1;
        int maxSum = 0;
        ArrayList<Integer> Even = new ArrayList<Integer>();
        ArrayList<Integer> Odd = new ArrayList<Integer>();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 2 == 1) 
                Odd.add(arr[i]);
            else 
                Even.add(arr[i]);
        }
        Collections.sort(Odd);
        Collections.sort(Even);
        System.out.println(Odd);
        System.out.println(Even);
        int i = Even.size() - 1;
        int j = Odd.size() - 1;
        while (K > 0) {
            if (K % 2 == 1) {
                 if (i >= 0) {
                     System.out.println("1st if :"+(maxSum += Even.get(i)));
                     i--;
                }
                 else return -1;
                      K--;
            }
            else if (i >= 1 && j >= 1) {
                if (Even.get(i) + Even.get(i - 1)<= Odd.get(j) + Odd.get(j - 1)) {
                     System.out.println("if of else if"+ (maxSum += Odd.get(j) + Odd.get(j - 1)));
                     j -= 2;
                }
                else {
                     System.out.println("else of else if "+(maxSum += Even.get(i) + Even.get(i - 1)));
                     i -= 2;
                }
                 K -= 2;
            }
             else if (i >= 1) {
                 System.out.println("else if of else if 1"+(maxSum += Even.get(i) + Even.get(i - 1)));
                 i -= 2;
                 K -= 2;
            }
             else if (j >= 1) {
                 System.out.println("else if of else if"+(maxSum += Odd.get(j) + Odd.get(j - 1)));
                 j -= 2;
                 K -= 2;
            }
        }
        return maxSum;
    }
	    public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    	int N = sc.nextInt();
	    	int arr[] = new int[N];
	    	int K = sc.nextInt();
	    	for (int i = 0; i < arr.length; i++) 
	            arr[i] = sc.nextInt();
	    		System.out.print(solution(arr,K));
		}
}
