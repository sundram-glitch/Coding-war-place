package com.sd.logics;

import java.util.Scanner;

public class Mgical_String {
  public static void main(String[] args) {
   System.out.println(MagicalStringCount(new Scanner(System.in).next()));
  }

  static int MagicalStringCount(String str) {
    char ch [] = str.toCharArray();
    int count = ch.length;
    
	   return count;
}
}
