package com.sd.logics;

import java.util.*;

public class FIXFIX {
    static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
     int T = sc.nextInt();
	  while(T!=0) {
		  solve();
	 T--;
	  }
  }
	  static void solve() {
	 int n = sc.nextInt(); int k = sc.nextInt();
	 int check = k;
	 check++;
	 if(k==n-1) { 
		 System.out.println(-1);
	  return;
	 } int i ;
	 for(i = 1; i<=n;i++) {
		if(k==0)break;
		System.out.print(i+" ");
		k--;
	 }
	Vector<Integer> temp = new Vector<>();
	for (int j = n; j <=i; j--) {
		if(j==check) {
			//temp.add(temp.p);
		}
	}
   }
}