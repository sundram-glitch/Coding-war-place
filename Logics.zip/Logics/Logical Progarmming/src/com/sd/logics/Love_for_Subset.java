package com.sd.logics;

import java.util.Scanner;

public class Love_for_Subset {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int T = sc.nextInt();
	while(T!=0) {
		 int set = sc.nextInt();
		 if(set == 1) System.out.println(1);
		 else System.out.println(set-1);
		 T--;
		}
  }
}
