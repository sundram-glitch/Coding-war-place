package com.sd.logics;

import java.util.Scanner;

public class Mobile_Game_Play {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int N =sc.nextInt();
	int mod = 0 , rev =0, div = N;
	while(div!=0) {
    mod = div%10;
    rev =rev*10+mod; 
    div /=10;
	}
	System.out.println(rev);
	System.out.print(N-rev);
	}
}
