package com.sd.logics;

import java.util.*;
public class ORorXOR {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int l = sc.nextInt();
	int u = sc.nextInt();
	System.out.println(MaximumXOR(l,u));
  }

  static int MaximumXOR(int l, int u) {
    ArrayList<Integer> al = new ArrayList<Integer>();
	  int temp = l+1;
	  while(temp<=u) {
		  al.add(l^temp);
		  temp++;
	  }
	  return Collections.max(al);
}
}
