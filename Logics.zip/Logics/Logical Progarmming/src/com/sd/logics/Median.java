package com.sd.logics;

import java.util.Arrays;
import java.util.Scanner;

public class Median {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int arr[] = {sc.nextInt(),sc.nextInt(),sc.nextInt()};
	Arrays.parallelSort(arr);
	System.out.println(arr[1]);
}
}
