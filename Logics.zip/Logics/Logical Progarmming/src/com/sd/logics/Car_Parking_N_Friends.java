package com.sd.logics;

//1 4 1 -- 1 5 1
import java.util.*;
public class Car_Parking_N_Friends {
	static int car;
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int size = sc.nextInt();
	int arrP[] = new int[size];
	int arrS[] = new int[size];
    for (int i = 0; i < arrS.length; i++)
    	arrP[i] = sc.nextInt();
    for (int i = 0; i < arrS.length; i++) 
    	arrS[i] = sc.nextInt();
    System.out.print(solution(arrP,arrS));
  }

  public static int solution(int[] arrP, int[] arrS) {
     for (int i = 0; i < arrP.length-1; i++) {
	   if(arrP[i]<arrS[i] && arrP[i]>arrP[i+1]) {
		   check(arrP, i, arrS);
	   }
     }
	  return Math.abs(arrP.length-car);
  }

  static void check(int[] arrP, int i,int arrS[]) {
    int j =0;
	  for( j = 0; i < arrP.length; i++) {
	  while(arrP[j]<arrP[i] && arrP[i]<arrS[i] && arrP[j]!=0) {
		arrP[i] +=1;  
	    arrP[j]-=1;
	  }
    }
    if(arrP[j]==0) car++;
  }
}
