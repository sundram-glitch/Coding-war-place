package com.sd.logics;

import java.util.Scanner;

public class Harsh_No {
  static Scanner scan = new Scanner(System.in);
  public static void main(String[] args) {
	int t = scan.nextInt();
	check(t);
    }

 static void check(int t) {
	while(t!=0) {
	int steps = 0;
	int A = scan.nextInt();
	int B =scan.nextInt();
	int temp = A;
	while(A!=B) {
	if(A>B) {
		A /=temp;
	steps++;
	}
	else if(A<B) {
		A *=B;
	steps++;
	}
	}
	if(A==B) System.out.println(steps);	
	t--;
	}
}
}
