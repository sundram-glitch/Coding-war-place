package com.sd.logics;

import java.util.ArrayList;
import java.util.Scanner;

public class Rotations {
    /*public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int d = scan.nextInt();
        int[] array = new int[n];
        for(int i=0; i<n;i++) 
            array[(i+n-d)%n] = scan.nextInt();
        for(int i=0; i<n;i++) 
            System.out.print(array[i] + " ");
    }*/
    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
    	int n = scan.nextInt();
    	ArrayList<Integer> al = new ArrayList<>(n);
    	int d = scan.nextInt();
    	for(int i=0; i<n;i++)
    		al.add((i+n-d)%n, scan.nextInt());
    	for(int i=0; i<n;i++) 
    		System.out.print(al.get(i) + " ");
    }
}
