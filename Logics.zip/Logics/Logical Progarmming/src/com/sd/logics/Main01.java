package com.sd.logics;

import java.util.LinkedHashSet;
import java.util.Scanner;

public class Main01 {
	public static void main(String[] args) {
	Scanner scn = new Scanner(System.in);
	int t = scn.nextInt();
	while(t!=0) {
	int n = scn.nextInt(); 
	int arr[] = new int[n];
	for (int i = 0; i < arr.length; i++) arr[i] = scn.nextInt();
	for (int j = 0; j < arr.length; j++) {
		if(j<n-2) 
		if(arr[j]==arr[j+1]) {
			if(j==n-1)System.out.println(1);
		}
		//else callMethod();
	}
			LinkedHashSet<Integer> unq=new LinkedHashSet<Integer>();
			for (int i = 0; i < arr.length; i++) 
		          for (int k = 0+i; k < arr.length; k++) {
					if(arr[i]!=arr[k]) {
						unq.add(arr[k]);
						if(k==arr.length-1) {
						System.out.println(unq.size());
						return;
						}
						}
			      }
	     }
	t--;
}
}
/*Sample input
3
7 2
1 2 3 4 4 4 4
5 3
1 2 3 1 2
5 3
5 5 5 5 5

Sample output
3
2
1*/