package com.sd.logics;

import java.util.*;

public class Count_Cube {
  public static void main(String[] args) {
	 Scanner sc = new Scanner( System.in);
	 int N = sc.nextInt();
	 int arr[ ] = new int[N];
	 for (int i = 0; i < arr.length; i++)
		 arr[i]  = sc.nextInt();
	 int count  = 0;
	 for (int i = 0; i < arr.length; i++) {
		 if(arr[i]==1) {
			 count++;
		 continue;
		 }
		for (int j = 2; j <=arr[i]; j++) {
			if(arr[i]%j == 0 && arr[i] == (j*j*j)) {
				count++; 
				break;
			}
		}
	 }
	 System.out.print(count);
  }
}
