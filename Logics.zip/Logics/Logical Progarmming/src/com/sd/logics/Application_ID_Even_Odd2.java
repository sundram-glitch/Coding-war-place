package com.sd.logics;

import java.util.*;
public class Application_ID_Even_Odd2 {
  public static void main(String[] args) {
	int applicationID = new Scanner(System.in).nextInt();
  check(applicationID);
  }//Sundram Dubey
  private static void check(int applicationID) {
  String str = Integer.toString(applicationID);
  int arr [] = new int[str.length()];
  int mod = 0, div = applicationID, i =0;
	  while(div!=0) {
		mod = div%10;
		if(mod%2==0) 
			arr[i++] = mod+1;
		else
			arr[i++]= mod-1;
		div /=10;
	}
	for (int i1 = arr.length-1; i1 >=0; i1--)
	 System.out.print(arr[i1]);
  }
}
