package com.sd.logics;

import java.util.*;
import java.util.Map.Entry;


public class Arrays_Gumrah {
  public static void main(String[] args) {
	Scanner get = new Scanner(System.in);
	Map<Integer, Integer> in = new LinkedHashMap<Integer, Integer>();
	List<Integer> list = new LinkedList<Integer>();
	Set<Integer> set = new LinkedHashSet<Integer>();
	int N = get.nextInt();
    int arr1 [] = new int[N]; 
    for (int i = 0; i < arr1.length; i++) 
    	arr1[i] = get.nextInt();
    for (int i : arr1) 
		in.put(i, in.getOrDefault(i, 0)+1);
    System.out.println(in);
    for (int i = 0; i < arr1.length; i++)
    	set.add(arr1[i]);
    Integer arr2[] = set.toArray(new Integer[set.size()]);
    for (int i = 0; i < arr2.length; i++) {
		for (int j = 0; j < arr2.length; j++) {
			//if(in.get(arr2[j])>
		}
	}
  }
}
