package com.sd.logics;

import java.util.Scanner;

public class Missing_No {
 
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int sum = 0, mis_No=0;
		int size = scan.nextInt();
		int arr[] = new int[size-1];
		for (int i = 0; i < arr.length; i++) 
			arr[i] = scan.nextInt();
		for (int i = 0; i < arr.length; i++) 
		sum += arr[i];
		System.out.println(sum);
		mis_No = (size*(size+1))/2;
		System.out.println(mis_No);
		System.out.println(mis_No-sum);
	}
}
