package com.sd.logics;

import java.util.*;

public class Order_Based_On_Index_Element_Frequency {
  static Integer[] arr = {2, 5, 2, 8, 5, 6, 8, 8};
  public static void main(String[] args) {
	/*List<Integer> list = Arrays.asList(arr);
	Set<Integer>  set = new LinkedHashSet<Integer>();
	Deque<Integer> queue = new ArrayDeque<Integer>();
	set.addAll(list);
	queue.addAll(list);
	System.out.println(set);
	System.out.println(list);
    System.out.println(queue);
    System.out.println(queue.pop());*/
	List<Integer> list = Arrays.asList(arr);
	System.out.println(list);
	sortBasedOnFrequencyAndValue(list);
  }
  private static void sortBasedOnFrequencyAndValue(List<Integer> list) {
	 int n = arr.length;
	 final HashMap<Integer, Integer> mapCount = new HashMap<Integer, Integer>();
	 final HashMap<Integer, Integer> mapIndex = new HashMap<Integer, Integer>();
	 for (int i = 0; i < arr.length; i++) {
		if(mapCount.containsKey(arr[i]))
			mapCount.put(arr[i], mapCount.get(arr[i])+1);
		else {
			mapCount.put(arr[i], 1);//Map to capture Count
			mapIndex.put(arr[i], i);//Map to capture 1st occurrence of elements 
		}
	}
	 System.out.println(mapCount+" "+mapIndex);
	 Collections.sort(list, new Comparator<Integer>() {
		 public int compare(Integer n1, Integer n2) {
		 int freq1 = mapCount.get(n1);
		 int freq2 = mapCount.get(n2);
		 if(freq1!=freq2) return freq2 - freq1;
		 else return mapIndex.get(n1)-mapIndex.get(n2);//Element with lesser index gets higher priority
		 }
	});
	 System.out.println(list);
}
}
