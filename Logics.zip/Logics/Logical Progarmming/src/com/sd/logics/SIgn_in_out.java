package com.sd.logics;

import java.util.*;
import java.util.Map.Entry;

public class SIgn_in_out {
  public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
	 Map<Integer, Integer> map= new LinkedHashMap<>();
	 ArrayList<Integer> al = new ArrayList<>();
	 //int size = sc.nextInt();
	 String [] strArr= new String[7];
	 for (int i = 0; i < strArr.length; i++) 
		 strArr[i] = sc.nextLine();
	 sc.close();
	 for (int i = 0; i < strArr.length; i++) {
		String newStr [] = strArr[i].split(" ");
		for (int j = 0; j < newStr.length-2; j++) 
			 map.put(Integer.parseInt(newStr[j]), Math.abs(Integer.parseInt(newStr[j+1])-(map.getOrDefault(Integer.parseInt(newStr[j]), 0))));
	 }
		int maxSpan = 20;
	 for (Entry<Integer, Integer> key : map.entrySet()) 
	     if(key.getValue()<=maxSpan)al.add(key.getKey());
	 Collections.sort(al);
	 System.out.println(al);
}
}
