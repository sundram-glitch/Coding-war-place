package com.sd.logics;

import java.util.LinkedList;
import java.util.Scanner;

public class Total_Time_AtoZ {

	public static void main(String[] args) {
	Scanner get = new Scanner(System.in);
		LinkedList<Character> strlist = new LinkedList<Character>();
    int index = 0, temp = 0;
		String str = get.next();
    for (int i = 0; i < 26; i++) 
	strlist.add((char) (65+i));
    for (int i = 0; i < str.length(); i++) {
    index = strlist.indexOf(str.charAt(i));
    temp = (Math.abs(index - temp))+1;
    System.out.print(temp);
    }
    System.out.println(temp);
	}
}
