package com.sd.logics;

import java.util.*;

public class weigthNvalue {
 public static void main(String[] args) {
   Scanner scan  = new Scanner(System.in);
   Map<Integer, Integer> m = new LinkedHashMap<>();
   int N = scan.nextInt();
   int Weight = scan.nextInt();
   int W[] = new int [N];
   int V[] = new int [N];
   int weighSum = 0;
   int valueSum = 0;
   for (int i = 0; i < V.length; i++)
	V[i] = scan.nextInt();
   for (int i = 0; i < V.length; i++) 
	W[i] = scan.nextInt();
   
   for (int i = 0; i < V.length; i++)
	for (int j = i; j < W.length-1; j++) {
	valueSum =V[i]+V[j+1];
	weighSum =W[i]+W[j+1];
		if(weighSum< Weight) m.put(valueSum, weighSum);
	}
    for (int i = 0; i < V.length/2; i++) {
	   valueSum =V[0];
	   weighSum =W[0];
	for (int j = 1+i; j < V.length-1+i ; j++) {
		valueSum +=V[j];
		weighSum +=W[j];
	}
	if(weighSum< Weight) m.put(valueSum, weighSum);
   }
    int temp =0;
   System.out.println(m);
   for (Integer key : m.keySet()) 
   if(key>temp)temp = key;
System.out.println(temp);
scan.close();
 }
}
