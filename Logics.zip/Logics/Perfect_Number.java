import java.util.Scanner;
class  Perfect_Number
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter No :");
		int n = scan.nextInt();
	    int i =1,sum = 0;
		while(i <= n/2)
		{
        if(n%i==0) sum +=i;
		i++;
		}
		System.out.print(sum);
	}
}
