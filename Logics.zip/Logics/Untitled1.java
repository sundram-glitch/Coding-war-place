class  TestQuiz01{
	public static void main(String[] args) {
		int i =4, j = -1, k = 0, w=0,x=0,y=0,z=0;
		w = i || j || k;
		y = i && j && k;
		z = i && j || k;
		System.out.println("w = "+w+"x ="+x+"y = "+y+"z = "+z);
	}
}
