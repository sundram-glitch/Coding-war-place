package com.sd.comparator;

import java.util.*;

public class Comparators {
  public static void main(String[] args) {
	 TreeSet<String> set1 = new TreeSet<>();
	 set1.add("a");
	 set1.add("b");
	 set1.add(" ");
	 set1.add("c");
	 System.out.println(set1);
	 TreeSet<String> set2 = new TreeSet<String>( new Comparator<String>() {
		@Override
		public int compare(String o1, String o2) {
			return o2.compareTo(o1);
		}
	 });
     
	 set2.add("d");
	 set2.add("a");
	 set2.add("c");
	 set2.add("b");
	 System.out.println(set2);
	 //TreeSet<String> set3 = new TreeSet<String>((s1, s2 )->{ return s1.compareTo(s2);});
	 TreeSet<String> set3 = new TreeSet<String>((s1, s2 )-> s1.compareTo(s2));
  }
}
