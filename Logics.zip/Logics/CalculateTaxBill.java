class  CalculateTaxBill{
	
	
	
	
	
	//Sundram
	public static int calcTotalTax(int first,int sec[]){
    int i =0,sum=0,total_bill=0,tax_amount=0;
    for (i=0;i<first ;i++ ) sum +=sec[i];
	System.out.println(sum);
	if(sum >= 1000) tax_amount = (sum-1000)/10;
	total_bill = sum + tax_amount;
    return total_bill;
	}














	public static void main(String...args){
    System.out.println(calcTotalTax(5, new int[]{100,299,370,455,110,888}));
	}
}
