package sept.longer.challenge;

import java.util.Scanner;

public class AirLine_Sol2 {
 public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int testCase = scan.nextInt();
	while(testCase!=0) {
	int arr[] = new int [5];
	for (int i = 0; i < arr.length; i++) 
		arr[i] = scan.nextInt();
	if(arr[0]+arr[1]<=arr[arr.length-2] && arr[2]<=arr[arr.length-1]) System.out.println("Yes");
	else if(arr[0]+arr[2]<=arr[arr.length-2] && arr[1]<=arr[arr.length-1]) System.out.println("Yes");
	else if(arr[2]+arr[1]<=arr[arr.length-2] && arr[0]<=arr[arr.length-1]) System.out.println("Yes");
	else System.out.println("No");
	testCase--;
	}
	scan.close();
}
}
