package sept.longer.challenge;

import java.util.Scanner;

public class SHUFFLIN2 {
  public static void main(String[] args) {
	Scanner get = new Scanner(System.in);
	int testCase = get.nextInt();
    while(testCase !=0) {
    	int  sum =0, even =0, odd=0;
    int  N = get.nextInt();
    int A[] = new int[N];
    int Aeven = N/2; int Aodd = N - Aeven;
    for (int i = 0; i < A.length; i++)
    	A[i] = get.nextInt();
    for (int i = 0; i <A.length; i++) {
    if(A[i]%2==0) even++;
    else odd++;
    }
    if(Math.abs(Aeven-odd)>0)
    	sum = Aeven-odd;
    else sum = Aodd - even;
	System.out.println(N-(Math.abs(sum)));
	testCase--;
    }
  }
}
