package sept.longer.challenge;

import java.util.LinkedList;
import java.util.Scanner;

public class XoR {
 public static void main(String[] args) {  
	 Scanner scan = new Scanner(System.in);
	 int N = scan.nextInt();
	 LinkedList<Integer> list = new LinkedList<Integer>();
     int res =0;
	 for (int i = 0; i < N; i++) {
		list.add(scan.nextInt());
     res = list.get(i)^5;
     System.out.println(res);
     }
}
}
