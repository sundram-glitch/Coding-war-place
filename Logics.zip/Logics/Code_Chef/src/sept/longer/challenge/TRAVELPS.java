package sept.longer.challenge;

import java.util.Scanner;

public class TRAVELPS {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int testCase = scan.nextInt();
	while(testCase!=0) {
	int len = scan.nextInt(); 
	int A = scan.nextInt(); 
	int B =scan.nextInt(); 
	String str = scan.next();
	if(str.length() == len) {
		int sum =0;
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i) == '0') sum +=A;
			else sum +=B;
		}
		System.out.println(sum);
	}
	testCase--;
	}
	scan.close();
}
}//;)
