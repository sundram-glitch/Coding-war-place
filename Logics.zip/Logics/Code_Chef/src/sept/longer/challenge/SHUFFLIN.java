package sept.longer.challenge;

import java.util.Scanner;

public class SHUFFLIN {
 public static void main(String[] args) {
	  Scanner scan = new Scanner(System.in);
	  int testCase = scan.nextInt();
	  while(testCase!=0) {
	  int temp = 0, sum = 0;
	  int N = scan.nextInt();
	  int A[] = new int[N];
	  int B[] = new int[N];
	  for (int i = 0; i < A.length; i++)
		  A[i] = scan.nextInt();
      int even = N/2;
      int odd = N - N/2;
      for (int i = 0; i < A.length-1; i++) {
		 if(A[i]%2==0 && i%2==0) continue;
		 else if(A[i]%2==1 && i%2==0) {
			 temp = A[i];
			 A[i] = A[i+1];
			 A[i+1] = temp;
			 i = -1;
			 }
		 else if(A[i]%2==0 && i%2==1) {
			 temp = A[i];
			 A[i] = A[i+1];
			 A[i+1] = temp;
			 i = -1;
			 }
		 }
     for (int i = 0; i < B.length; i++)
	  B[i] = (A[i]+i+1)%2;
	  for (int j = 0; j < B.length; j++) 
		  sum +=B[j];
	  System.out.println(sum);
		  testCase--;
	  }
}
}
