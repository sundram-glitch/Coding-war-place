package sept.longer.challenge;

import java.util.Arrays;
import java.util.Scanner;

public class AIRLINE {
	public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int testCase = scan.nextInt();
    int cond1 = 0, cond2 = 0 , temp = 0, max = 0, inc = 0 ;
    int recall [] = new int[3];
    while(testCase!=0) {
    int arr[] = new int[3];
    max = 0;
    for (int i = 0; i < arr.length; i++) 
    	arr[i] = scan.nextInt();
    cond1 = scan.nextInt(); cond2 = scan.nextInt();
    Arrays.sort(arr);
    int min = arr[0];
    for (int i = 0; i < arr.length-1; i++) {
		max +=  Integer.max(arr[i], arr[i+1]);
		temp = Integer.min(arr[i], arr[i+1]);
		    if(temp <= min)
		    	temp = min;
	}
     if(max <=cond1 && min <= cond2) 
    	recall[inc++] = 1;
    else recall[inc++] = 0;
    testCase--;
    }
    for (int i = 0; i < recall.length; i++) {
		if(recall[i] == 1)
    	System.out.println("Yes");
		else System.out.println("No");
	}
    scan.close();
	}
}