
//AMCAT
	public class Solution
{
		static int orderID_size;
	
	public static int[]  prodDelivery(int[] orderID)
	{
		
	int[]  answer = new int[orderID_size];
		
		// Write your code here
		
		      for (int i =0; i< orderID.length ;i++){
				int arr = orderID[i];
				while(arr!=0){
				answer[i] += arr%10;
                arr/=10;
				}
		      }
			
	return answer;
			
}
		

	public static void main(String[] args)
	{
			
		java.util.Scanner in = new java.util.Scanner(System.in);
			
		//input for orderID
		
			        orderID_size = in.nextInt();
			
		int orderID[] = new int[orderID_size];
			
		for(int idx = 0; idx < orderID_size; idx++)


			                orderID[idx] = in.nextInt();
		
			        int[] result = prodDelivery(orderID);
			
	    for(int idx = 0; idx < result.length - 1; idx++)
			        System.out.print(result[idx] + " ");
	
			        System.out.print(result[result.length - 1]);
	
				}
			
}
