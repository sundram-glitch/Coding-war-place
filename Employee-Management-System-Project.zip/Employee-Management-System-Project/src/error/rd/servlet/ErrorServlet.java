package error.rd.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/errorurl")
public class ErrorServlet extends HttpServlet{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
System.out.println("ErrorServlet.doGet(-,-)");
	PrintWriter pw=null;
//get PrintWriter 
pw=res.getWriter();
//set Response Content Type 
 res.setContentType("text/html");
 //display message
 pw.println("<h1 style='color:red;text-align:center'>Internal Problem--Try Again</h1>");
 pw.println("<br><a href='input.html'>home</a>");
 
 //close stream
 pw.close();
 }//doGet(-,-);
public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
System.out.println("ErrorServlet.doPost()");
	doGet(req,res);  
 }//doPost(-,-);
}//class