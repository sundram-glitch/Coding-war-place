package error.rd.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmployeeSearchServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String GET_EMP_DETAILS_BY_NO="SELECT EMPNO,ENAME,JOB,SAL,DEPTNO FROM EMP WHERE EMPNO=?";

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		System.out.println("EmployeeSearchServlet.doGet()");   
		PrintWriter pw=null;
		int eno=0;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		RequestDispatcher rd=null;	
		try{
		//get PrintWriter 
		pw=res.getWriter();
		//set content type
	  // res.setContentType("applicaion/msword");
	  // res.addHeader("Content-Deposition","attachment;filename=result.doc");
		//read from 
        eno=Integer.parseInt(req.getParameter("eno"));
		//register jdbc driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		/*oracle.jdbc.driver.OracleDriver driver=new oracle.jdbc.driver.OracleDriver();
		DriverManager.registerDriver(driver);*/
	    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sundram");
		ps=con.prepareStatement(GET_EMP_DETAILS_BY_NO);
		//set query param values
		ps.setInt(1,eno);
		//execute the query 
		rs=ps.executeQuery();
		//Process The ResultSet Object 
		if(rs.next()){
		pw.println("<h1>Employee Details are </h1>");
		pw.println("<b> emp No::</b>"+rs.getInt(1)+"<br>");
		pw.println("<b> emp Name::</b>"+rs.getString(2)+"<br>");
		pw.println("<b> emp Job::</b>"+rs.getString(3)+"<br>");
		pw.println("<b> emp Salary::</b>"+rs.getFloat(4)+"<br>");
		pw.println("<b> emp Deptno::</b>"+rs.getInt(5)+"<br>");
		}
		else{
        pw.println("<h1 style='color:red'>Employee not Found</h1>");
		}//if
	}//try
catch(Exception e){//knon Exception
rd=req.getRequestDispatcher("/errorurl");
System.out.println("EmployeeSearchServlet.doGet() before rd.forwardd(-,-)");
rd.forward(req,res);
System.out.println("EmployeeSearchServlet.doGet() after rd.forward");
}
	finally{//close object
		try{
			if (rs!=null)
				rs.close();
		}
		catch(SQLException se){
			se.printStackTrace();
		}
			try{
			if (ps!=null)
				ps.close();
		}
		catch(SQLException se){
			se.printStackTrace();
		}
			try{
			if (con!=null)
				con.close();
		}
		catch(SQLException se){
			se.printStackTrace();
		}
			pw.println("<br> <br><h1>hi</h1>");
		pw.println("<br> <br><a href='input.html'>Home</a>");
			try{
			if (pw!=null)
				pw.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	 }//finally
  }//main
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	  doGet(req,res);
  }
}//class
	
