package com.marlabs.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "emp_tab")
public class Employee {
	@Id
	@GeneratedValue
	@Column(name = "emp_id")
	private Integer empId;
	@Column(name = "first_name")
	private String fname;
	@Column(name = "middle_name")
	private String mName;
	@Column(name = "last_name")
	private String lName;
	@Column(name = "emp_no")
	private String empNo;
	private String empAadhar;
	private String contact;
	private String dob;

	public Employee() {
		super();
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	public String getEmpAadhar() {
		return empAadhar;
	}

	public void setEmpAadhar(String empAadhar) {
		this.empAadhar = empAadhar;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", fname=" + fname + ", mName=" + mName + ", lName=" + lName + ", empNo="
				+ empNo + ", empAadhar=" + empAadhar + ", contact=" + contact + ", dob=" + dob + "]";
	}

}
