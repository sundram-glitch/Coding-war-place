package com.marlabs.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "work_skils")
public class WorkExpAndSkils {
	@Id
	@GeneratedValue
	private Integer skilsId;
	private String title;
	private String empId;
	@Column(name = "dept")
	private String department;
	@Column(name = "workloc")
	private String workLocation;
	private String emailid;
	@ElementCollection
	private List<String> number;
	private String startDate;
	private String salary;
	private String skils;

	public WorkExpAndSkils() {
		super();
	}

	public WorkExpAndSkils(Integer skilsId) {
		super();
		this.skilsId = skilsId;
	}

	public Integer getSkilsId() {
		return skilsId;
	}

	public void setSkilsId(Integer skilsId) {
		this.skilsId = skilsId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public List<String> getNumber() {
		return number;
	}

	public void setNumber(List<String> number) {
		this.number = number;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getSkils() {
		return skils;
	}

	public void setSkils(String skils) {
		this.skils = skils;
	}

	@Override
	public String toString() {
		return "WorkExpAndSkils [skilsId=" + skilsId + ", title=" + title + ", empId=" + empId + ", department="
				+ department + ", workLocation=" + workLocation + ", emailid=" + emailid + ", number=" + number
				+ ", startDate=" + startDate + ", salary=" + salary + ", skils=" + skils + "]";
	}

}
