package com.marlabs.config;

import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@EnableWebMvc
@Configuration
@ComponentScan("com.marlabs")
@EnableTransactionManagement
public class AppConfig implements WebMvcConfigurer {

	@Bean
	public BasicDataSource bds() {
		BasicDataSource d = new BasicDataSource();
		d.setDriverClassName("com.mysql.jdbc.Driver");
		d.setUrl("jdbc:mysql://localhost:3306/emp");
		d.setUsername("root");
		d.setPassword("root");
		return d;
	}

	@Bean
	public Properties prop() {
		Properties p = new Properties();
		p.put("hibernate.dialect", "org.hibernate.dialect.MySQL55Dialect");
		p.put("hibernate.show_sql", "true");
		p.put("hibernate.format_sql", "true");
		p.put("hibernate.hbm2ddl.auto", "create");
		return p;
	}

	@Bean
	public LocalSessionFactoryBean sf() {
		LocalSessionFactoryBean l = new LocalSessionFactoryBean();
		l.setDataSource(bds());
		l.setHibernateProperties(prop());
		l.setPackagesToScan("com.marlabs.model");
		return l;
	}

	@Bean
	public HibernateTransactionManager htm() {
		HibernateTransactionManager h = new HibernateTransactionManager();
		h.setSessionFactory(sf().getObject());
		return h;
	}

	@Bean
	public HibernateTemplate ht() {
		HibernateTemplate h = new HibernateTemplate();
		h.setSessionFactory(sf().getObject());
		return h;
	}

	@Bean
	public InternalResourceViewResolver iv() {
		InternalResourceViewResolver i = new InternalResourceViewResolver();
		i.setPrefix("/WEB-INF/page/");
		i.setSuffix(".jsp");
		return i;
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}
}
