package com.marlabs.service;

import com.marlabs.model.EmergencyContact;

public interface IEmergencyContactService {
	Integer saveEmergencyContact(EmergencyContact emc);

}
