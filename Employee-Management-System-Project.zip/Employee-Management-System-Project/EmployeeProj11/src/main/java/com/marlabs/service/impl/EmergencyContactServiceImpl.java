package com.marlabs.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.marlabs.dao.IEmergencyContactDao;
import com.marlabs.model.EmergencyContact;
import com.marlabs.service.IEmergencyContactService;

@Service
public class EmergencyContactServiceImpl implements IEmergencyContactService {
	@Autowired
	private IEmergencyContactDao dao;

	@Transactional
	@Override
	public Integer saveEmergencyContact(EmergencyContact emc) {
		return dao.saveEmergencyContact(emc);
	}

}
