package com.marlabs.dao;

import com.marlabs.model.WorkExpAndSkils;

public interface IWorkExpDao {
	Integer saveWorkExp(WorkExpAndSkils wes);

}
