package com.marlabs.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emerg_cont")
public class EmergencyContact {
	@Id
	@GeneratedValue
	private Integer emrgCntId;
	private String fName;
	private String lName;
	private String address;
	private String city;
	private String state;
	private String zipCode;
	@ElementCollection
	private List<String> phnNumber;
	@Column(name = "relation")
	private String relationship;

	public EmergencyContact(Integer emrgCntId) {
		super();
		this.emrgCntId = emrgCntId;
	}

	public EmergencyContact() {
		super();
	}

	public Integer getEmrgCntId() {
		return emrgCntId;
	}

	public void setEmrgCntId(Integer emrgCntId) {
		this.emrgCntId = emrgCntId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public List<String> getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(List<String> phnNumber) {
		this.phnNumber = phnNumber;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	@Override
	public String toString() {
		return "EmergencyContact [emrgCntId=" + emrgCntId + ", fName=" + fName + ", lName=" + lName + ", address="
				+ address + ", city=" + city + ", state=" + state + ", zipCode=" + zipCode + ", phnNumber=" + phnNumber
				+ ", relationship=" + relationship + "]";
	}
}
