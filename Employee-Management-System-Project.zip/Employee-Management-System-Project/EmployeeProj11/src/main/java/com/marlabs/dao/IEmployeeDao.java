package com.marlabs.dao;

import java.util.List;

import com.marlabs.model.Employee;

public interface IEmployeeDao {
	Integer saveEmployee(Employee emp);

	void updateEmployee(Integer id);

	void deleteEmployee(Integer id);

	Employee getOneEmployee(Integer id);

	List<Employee> getAllEmployee();

}
