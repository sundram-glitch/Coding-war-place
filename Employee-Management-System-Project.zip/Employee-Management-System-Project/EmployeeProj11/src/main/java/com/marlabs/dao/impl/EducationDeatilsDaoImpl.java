package com.marlabs.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.marlabs.dao.IEduactionDetailsDao;
import com.marlabs.model.EducationalDetails;

@Repository
public class EducationDeatilsDaoImpl implements IEduactionDetailsDao {
	@Autowired
	private HibernateTemplate ht;

	@Override
	public Integer saveEducation(EducationalDetails eud) {
		return (Integer) ht.save(eud);
	}

}
