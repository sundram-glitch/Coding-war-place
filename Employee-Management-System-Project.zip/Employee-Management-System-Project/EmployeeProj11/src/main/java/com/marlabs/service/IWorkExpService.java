package com.marlabs.service;

import com.marlabs.model.WorkExpAndSkils;

public interface IWorkExpService {
	Integer saveWorkExp(WorkExpAndSkils wes);

}
