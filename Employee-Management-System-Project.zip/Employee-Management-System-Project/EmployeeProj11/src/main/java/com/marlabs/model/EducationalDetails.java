package com.marlabs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

@Entity
@Table(name = "high_school")
@SecondaryTables({ @SecondaryTable(name = "inter", pkJoinColumns = @PrimaryKeyJoinColumn(name = "eduFk")),
		@SecondaryTable(name = "graduat", pkJoinColumns = @PrimaryKeyJoinColumn(name = "edufk")),
		@SecondaryTable(name = "postgraduat", pkJoinColumns = @PrimaryKeyJoinColumn(name = "edufk")) })
public class EducationalDetails {
	// high school
	@Id
	@GeneratedValue
	private Integer eduId;
	@Column(name = "exam")
	private String examinationHighSchool;
	@Column(name = "yr_of_ps")
	private String yearOfPassingHighSchool;
	@Column(name = "bord")
	private String boarHdighSchool;
	@Column(name = "marks")
	private String marksHighSchool;

	// Intermediate
	@Column(name = "exam", table = "inter")
	private String examinationIntermediate;
	@Column(name = "yr_of_ps", table = "inter")
	private String yearOfPassingIntermediate;
	@Column(name = "bord", table = "inter")
	private String boardIntermediate;
	@Column(name = "marks", table = "inter")
	private String marksIntermediate;
	// Graduation
	@Column(name = "exam", table = "graduat")
	private String examinationGraduate;
	@Column(name = "yr_of_ps", table = "graduat")
	private String yearOfPassingGraduate;
	@Column(name = "bord", table = "graduat")
	private String boardGraduate;
	@Column(name = "marks", table = "graduat")
	private String marksGraduate;

	// PostGraduation
	@Column(name = "exam", table = "postgraduat")
	private String examinationPostGraduate;
	@Column(name = "yr_of_ps", table = "postgraduat")
	private String yearOfPassingPostGraduate;
	@Column(name = "bord", table = "postgraduat")
	private String boardPostGraduate;
	@Column(name = "marks", table = "postgraduat")
	private String marksPostGraduate;

	public EducationalDetails() {
		super();
	}

	public EducationalDetails(Integer eduId) {
		super();
		this.eduId = eduId;
	}

	public Integer getEduId() {
		return eduId;
	}

	public void setEduId(Integer eduId) {
		this.eduId = eduId;
	}

	public String getExaminationHighSchool() {
		return examinationHighSchool;
	}

	public void setExaminationHighSchool(String examinationHighSchool) {
		this.examinationHighSchool = examinationHighSchool;
	}

	public String getYearOfPassingHighSchool() {
		return yearOfPassingHighSchool;
	}

	public void setYearOfPassingHighSchool(String yearOfPassingHighSchool) {
		this.yearOfPassingHighSchool = yearOfPassingHighSchool;
	}

	public String getBoarHdighSchool() {
		return boarHdighSchool;
	}

	public void setBoarHdighSchool(String boarHdighSchool) {
		this.boarHdighSchool = boarHdighSchool;
	}

	public String getMarksHighSchool() {
		return marksHighSchool;
	}

	public void setMarksHighSchool(String marksHighSchool) {
		this.marksHighSchool = marksHighSchool;
	}

	public String getExaminationIntermediate() {
		return examinationIntermediate;
	}

	public void setExaminationIntermediate(String examinationIntermediate) {
		this.examinationIntermediate = examinationIntermediate;
	}

	public String getYearOfPassingIntermediate() {
		return yearOfPassingIntermediate;
	}

	public void setYearOfPassingIntermediate(String yearOfPassingIntermediate) {
		this.yearOfPassingIntermediate = yearOfPassingIntermediate;
	}

	public String getBoardIntermediate() {
		return boardIntermediate;
	}

	public void setBoardIntermediate(String boardIntermediate) {
		this.boardIntermediate = boardIntermediate;
	}

	public String getMarksIntermediate() {
		return marksIntermediate;
	}

	public void setMarksIntermediate(String marksIntermediate) {
		this.marksIntermediate = marksIntermediate;
	}

	public String getExaminationGraduate() {
		return examinationGraduate;
	}

	public void setExaminationGraduate(String examinationGraduate) {
		this.examinationGraduate = examinationGraduate;
	}

	public String getYearOfPassingGraduate() {
		return yearOfPassingGraduate;
	}

	public void setYearOfPassingGraduate(String yearOfPassingGraduate) {
		this.yearOfPassingGraduate = yearOfPassingGraduate;
	}

	public String getBoardGraduate() {
		return boardGraduate;
	}

	public void setBoardGraduate(String boardGraduate) {
		this.boardGraduate = boardGraduate;
	}

	public String getMarksGraduate() {
		return marksGraduate;
	}

	public void setMarksGraduate(String marksGraduate) {
		this.marksGraduate = marksGraduate;
	}

	public String getExaminationPostGraduate() {
		return examinationPostGraduate;
	}

	public void setExaminationPostGraduate(String examinationPostGraduate) {
		this.examinationPostGraduate = examinationPostGraduate;
	}

	public String getYearOfPassingPostGraduate() {
		return yearOfPassingPostGraduate;
	}

	public void setYearOfPassingPostGraduate(String yearOfPassingPostGraduate) {
		this.yearOfPassingPostGraduate = yearOfPassingPostGraduate;
	}

	public String getBoardPostGraduate() {
		return boardPostGraduate;
	}

	public void setBoardPostGraduate(String boardPostGraduate) {
		this.boardPostGraduate = boardPostGraduate;
	}

	public String getMarksPostGraduate() {
		return marksPostGraduate;
	}

	public void setMarksPostGraduate(String marksPostGraduate) {
		this.marksPostGraduate = marksPostGraduate;
	}

	@Override
	public String toString() {
		return "EducationalDetails [eduId=" + eduId + ", examinationHighSchool=" + examinationHighSchool
				+ ", yearOfPassingHighSchool=" + yearOfPassingHighSchool + ", boarHdighSchool=" + boarHdighSchool
				+ ", marksHighSchool=" + marksHighSchool + ", examinationIntermediate=" + examinationIntermediate
				+ ", yearOfPassingIntermediate=" + yearOfPassingIntermediate + ", boardIntermediate="
				+ boardIntermediate + ", marksIntermediate=" + marksIntermediate + ", examinationGraduate="
				+ examinationGraduate + ", yearOfPassingGraduate=" + yearOfPassingGraduate + ", boardGraduate="
				+ boardGraduate + ", marksGraduate=" + marksGraduate + ", examinationPostGraduate="
				+ examinationPostGraduate + ", yearOfPassingPostGraduate=" + yearOfPassingPostGraduate
				+ ", boardPostGraduate=" + boardPostGraduate + ", marksPostGraduate=" + marksPostGraduate + "]";
	}

}
