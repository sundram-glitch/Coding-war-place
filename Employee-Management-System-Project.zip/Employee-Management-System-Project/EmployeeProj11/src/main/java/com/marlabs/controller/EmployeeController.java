package com.marlabs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.marlabs.model.EducationalDetails;
import com.marlabs.model.EmergencyContact;
import com.marlabs.model.Employee;
import com.marlabs.model.WorkExpAndSkils;
import com.marlabs.service.IEducationDetailsService;
import com.marlabs.service.IEmergencyContactService;
import com.marlabs.service.IEmployeeService;
import com.marlabs.service.IWorkExpService;

@Controller
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	private IEmployeeService empService;
	@Autowired
	private IEducationDetailsService eduService;
	@Autowired
	private IWorkExpService workService;
	@Autowired
	private IEmergencyContactService emrgService;

	// Home Page
	@RequestMapping("/home")
	public String getPage() {
		return "HomePage";
	}

	@RequestMapping("/details")
	public String detailPage() {
		return "DetailsPage2";
	}

	// Employee
	@RequestMapping("/getdata")
	public String getEmpForm() {
		return "EmployeDetails";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveEmployee(@ModelAttribute Employee emp, ModelMap map) {
		Integer id = empService.saveEmployee(emp);
		String massage = "Employee Details Save  " + id + "   Successfully ";
		map.addAttribute("msg", massage);
		return "Education";
	}

	// Education
	@RequestMapping(value = "/edusave", method = RequestMethod.POST)
	public String saveEducationData(@ModelAttribute EducationalDetails edu, ModelMap map) {
		Integer id = eduService.saveEducation(edu);
		String message = "Education Save " + id + " Successfully";
		map.addAttribute("msg", message);
		return "WorkSkilsExp";

	}

	// work Skils
	@RequestMapping(value = "/saveWorkExp", method = RequestMethod.POST)
	public String saveWorkExp(@ModelAttribute WorkExpAndSkils wes, ModelMap map) {
		Integer id = workService.saveWorkExp(wes);
		String message = "Work And Exp " + id + "   Save Successfully";
		map.addAttribute("msg", message);
		return "EmergencyContact";
	}

	// Emergency Contact
	@RequestMapping(value = "/emrgCont", method = RequestMethod.POST)
	public String getEmrg(@ModelAttribute EmergencyContact cont, ModelMap map) {
		Integer id = emrgService.saveEmergencyContact(cont);
		String message = "Thank  for this employee   " + id;
		map.addAttribute("msg", message);
		return "Thankus";
	}
}
