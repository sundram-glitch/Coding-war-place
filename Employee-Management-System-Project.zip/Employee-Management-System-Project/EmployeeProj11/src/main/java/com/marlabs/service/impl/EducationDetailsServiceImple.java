package com.marlabs.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.marlabs.dao.IEduactionDetailsDao;
import com.marlabs.model.EducationalDetails;
import com.marlabs.service.IEducationDetailsService;

@Service
public class EducationDetailsServiceImple implements IEducationDetailsService {
	@Autowired
	private IEduactionDetailsDao dao;

	@Transactional
	@Override
	public Integer saveEducation(EducationalDetails eud) {
		return dao.saveEducation(eud);
	}

}
