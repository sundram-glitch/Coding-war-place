package com.marlabs.service;

import com.marlabs.model.EducationalDetails;

public interface IEducationDetailsService {
	Integer saveEducation(EducationalDetails eud);

}
