package com.marlabs.dao;

import com.marlabs.model.EducationalDetails;

public interface IEduactionDetailsDao {
	Integer saveEducation(EducationalDetails eud);
}
