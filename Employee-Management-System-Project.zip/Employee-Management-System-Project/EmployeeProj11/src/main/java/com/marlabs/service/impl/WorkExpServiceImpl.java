package com.marlabs.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.marlabs.dao.IWorkExpDao;
import com.marlabs.model.WorkExpAndSkils;
import com.marlabs.service.IWorkExpService;

@Repository
public class WorkExpServiceImpl implements IWorkExpService {
	@Autowired
	private IWorkExpDao dao;

	@Transactional
	@Override
	public Integer saveWorkExp(WorkExpAndSkils wes) {
		return dao.saveWorkExp(wes);
	}

}
