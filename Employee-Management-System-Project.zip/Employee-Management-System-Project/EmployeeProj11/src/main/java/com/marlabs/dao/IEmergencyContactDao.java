package com.marlabs.dao;

import com.marlabs.model.EmergencyContact;

public interface IEmergencyContactDao {
	Integer saveEmergencyContact(EmergencyContact emrgcnt);

}
