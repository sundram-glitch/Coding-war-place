package com.marlabs.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.marlabs.dao.IEmployeeDao;
import com.marlabs.model.Employee;
import com.marlabs.service.IEmployeeService;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	private IEmployeeDao dao;

	@Override
	@Transactional
	public Integer saveEmployee(Employee emp) {
		return dao.saveEmployee(emp);
	}

	@Override
	public void updateEmployee(Integer id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmployee(Integer id) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee getOneEmployee(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
